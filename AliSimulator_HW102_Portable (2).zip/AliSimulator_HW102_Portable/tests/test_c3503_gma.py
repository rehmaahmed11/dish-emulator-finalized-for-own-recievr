"""Focused tests for the C3503-scoped GMA layer-0 keep-alive policy."""
import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))

from chips.c3503 import C3503


class FakeSim:
    def __init__(self):
        self.handlers = {}
        self.registers = {}

    def _mmio_on(self, kind, handler, start, end):
        self.assert_kind(kind)
        for offset in range(start, end + 1):
            self.handlers.setdefault(offset, []).append(handler)

    def _mmio_off(self, kind, handler, start, end):
        self.assert_kind(kind)
        for offset in range(start, end + 1):
            callbacks = self.handlers.get(offset, [])
            if handler in callbacks:
                callbacks.remove(handler)
            if not callbacks:
                self.handlers.pop(offset, None)

    @staticmethod
    def assert_kind(kind):
        if kind != "w":
            raise AssertionError(f"unexpected MMIO hook kind {kind!r}")

    def write(self, offset, value, size=4):
        mask = (1 << (size * 8)) - 1
        value &= mask
        address = 0xB8000000 + offset
        for callback in self.handlers.get(offset, ()):
            stored = callback(None, 0, address, size, value, None)
            if stored is not None:
                value = stored & mask
        self.registers[offset] = value
        return value


class C3503GmaTests(unittest.TestCase):
    @staticmethod
    def make_chip(chip_id=0x3503):
        chip = object.__new__(C3503)
        chip.chip_id = chip_id
        chip.sim = FakeSim()
        chip._gma_keep_alive_handler = None
        return chip

    def test_c3503c_and_c3503d_writes_cannot_clear_layer0_enable(self):
        for variant in (0xC000, 0xD000):
            with self.subTest(variant=hex(variant)):
                chip = self.make_chip()
                chip.chip_variant = variant
                self.assertTrue(chip._install_gma_keep_alive())
                self.assertEqual(chip.sim.write(0x6300, 0), 1)
                self.assertEqual(chip.sim.write(0x6300, 0x40000), 0x40001)
                self.assertEqual(chip.sim.write(0x6301, 0), 0)
                self.assertEqual(chip.sim.write(0x6380, 0), 0)

    def test_uninstall_removes_the_policy_hook(self):
        chip = self.make_chip()
        chip._install_gma_keep_alive()
        self.assertEqual(chip.sim.write(0x6300, 0), 1)
        chip._remove_gma_keep_alive()
        self.assertEqual(chip.sim.write(0x6300, 0), 0)

    def test_chip_id_change_syncs_policy_and_policy_returns_after_restore(self):
        chip = self.make_chip()
        chip._gma_policy_installed = True
        chip._sync_gma_keep_alive()
        self.assertEqual(chip.sim.write(0x6300, 0), 1)

        chip.chip_id = 0x3507
        chip._sync_gma_keep_alive()
        self.assertEqual(chip.sim.write(0x6300, 0), 0)
        self.assertEqual(chip.sim.handlers, {})

        chip.chip_id = 0x3503
        chip._sync_gma_keep_alive()
        self.assertEqual(chip.sim.write(0x6300, 0), 1)

        chip._gma_policy_installed = False
        chip._remove_gma_keep_alive()
        self.assertEqual(chip.sim.write(0x6300, 0), 0)


if __name__ == "__main__":
    unittest.main()
