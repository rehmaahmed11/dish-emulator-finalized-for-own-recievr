"""Unforced HW102 input-path integration checks for both known image containers.

The GitHub-linked dump has different non-maincode bytes but its decompressed
maincode is byte-for-byte identical to the named HW102 ABS image. Tests use
its exact sidecar OTP record and the C3503 family GMA policy. They deliberately
do not call apply_input_workaround() or install a GMA test hook.
"""
import os
import sys
import time
import unittest

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))

import dump_catalog
import hw102_workaround
from simulator import AliMipsSimulator, flash_size_for
from uc_const import UC_MIPS_REG_GP


REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HW102_IMAGES = (
    os.path.join(REPO, "dumps", "HW102.02.999-V-5079-By-www.receiveroption.com.abs"),
    os.path.join(REPO, "dumps", "dump202611220911.abs"),
)
OTP_GATE_RECORD = bytes.fromhex("15e857a6be62471248a852a3e886b8ed")


@unittest.skipUnless(all(os.path.isfile(path) for path in HW102_IMAGES),
                     "both supported HW102 image containers must be present")
class Hw102InputFixIntegrationTests(unittest.TestCase):
    def _verify_image(self, image):
        sim = AliMipsSimulator(rom_size=flash_size_for(image), log_handler=lambda _m: None)
        sim.lzma_insns_per_byte = 0
        sim.setSPIDump(False)
        sim.setI2CDump(False)
        sim.setUartHandler(lambda _c: None)
        sim.loadFile(image)
        sim.attach_tuner()

        self.assertEqual(type(sim.chip).__name__, "C3503", image)
        self.assertEqual(sim.chip.chip_variant, 0xC000, image)
        self.assertEqual(sim.chip.otp.data[0x1C0:0x1D0], OTP_GATE_RECORD, image)
        self.assertTrue(hw102_workaround.install_hw102_ir_profile(sim), image)
        self.assertEqual(sim.ir_coding, "ext00", image)

        deadline = time.time() + 150
        while sim._vtime() < 89.0 and time.time() < deadline:
            sim.run(max_instructions=sim.instruction_count + 1_000_000)
        self.assertGreaterEqual(sim._vtime(), 89.0, f"firmware did not reach the input-ready UI: {image}")

        gp = sim.mu.reg_read(UC_MIPS_REG_GP) & 0xFFFFFFFF
        gate_addr = gp - hw102_workaround.HW102_GATE_GP_OFFSET
        self.assertEqual(sim.peek(gate_addr, 4), b"\0\0\0\0",
                         f"firmware should clear its own gate from the OTP comparison: {image}")
        self.assertGreater(sim.chip.otp.reads, 0, image)
        self.assertEqual(sim._mmio_view[0x6300] & 1, 1,
                         f"C3503 model must preserve GMA layer-0 bit 0: {image}")
        before = sim.capture_screen().copy()
        self.assertGreater(len(np.unique(before.reshape(-1, 3), axis=0)), 100,
                           f"GMA should produce the Installation screen: {image}")

        # The first NEC frame identifies the firmware's active 0x4040 profile;
        # the following RIGHT is the menu-navigation event under test.
        sim.press_key("RIGHT")
        prime_end = sim._vtime() + 2.3
        while sim._vtime() < prime_end and time.time() < deadline:
            sim.run(max_instructions=sim.instruction_count + 250_000)
        self.assertEqual(int.from_bytes(sim.peek(gp - 0x73D8, 4), "little"), 0x4040, image)
        self.assertEqual(sim.peek(gate_addr, 4), b"\0\0\0\0", image)

        before_navigation = sim.capture_screen().copy()
        ge_before = sim.ge_ops
        sim.press_key("RIGHT")
        key_end = sim._vtime() + 2.3
        while sim._vtime() < key_end and time.time() < deadline:
            sim.run(max_instructions=sim.instruction_count + 250_000)
        after = sim.capture_screen()

        self.assertEqual(sim.peek(gate_addr, 4), b"\0\0\0\0", image)
        self.assertEqual(int.from_bytes(sim.peek(gp - 0x73D8, 4), "little"), 0x4040, image)
        self.assertGreater(sim.ge_ops, ge_before, image)
        self.assertGreater(int(np.count_nonzero(np.any(before_navigation != after, axis=2))), 0,
                           f"RIGHT should move the visible menu selection: {image}")
        self.assertEqual(len(sim._irc_fifo), 0, f"IR waveform FIFO should drain: {image}")

    def test_firmware_gate_and_navigation_without_ram_or_gma_hooks(self):
        for image in HW102_IMAGES:
            with self.subTest(image=os.path.basename(image)):
                self._verify_image(image)


if __name__ == "__main__":
    unittest.main()
