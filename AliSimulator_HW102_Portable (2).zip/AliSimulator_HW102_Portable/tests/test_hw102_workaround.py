"""Fast tests for the HW102 IR profile, OTP sidecar and manual gate fallback."""
import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))

import dump_catalog
import hw102_workaround
import ir_remote


REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HW102 = os.path.join(REPO, "dumps", "HW102.02.999-V-5079-By-www.receiveroption.com.abs")
REPOSITORY_DUMP = os.path.join(REPO, "dumps", "dump202611220911.abs")


class FakeMu:
    def __init__(self, gp):
        self.gp = gp

    def reg_read(self, reg):
        return self.gp


class FakeSim:
    def __init__(self, dump_path, gp=0x809587A8):
        self.dump_path = dump_path
        self.ram_size = 16 * 1024 * 1024
        self.mu = FakeMu(gp)
        self._ir_key_table = None
        self.ir_coding = "nec"
        self.memory = bytearray(self.ram_size)
        self.mmio_hook = None

    def peek(self, address, size):
        start = address - 0x80000000
        return bytes(self.memory[start:start + size])

    def poke(self, address, data):
        start = address - 0x80000000
        self.memory[start:start + len(data)] = data

    def _mmio_on(self, mode, handler, start, end):
        self.mmio_hook = (mode, handler, start, end)


@unittest.skipUnless(os.path.isfile(HW102), "HW102 firmware image is not present")
class Hw102WorkaroundTests(unittest.TestCase):
    def test_only_known_exact_images_are_matched(self):
        self.assertTrue(hw102_workaround.is_hw102_image(HW102))
        self.assertFalse(hw102_workaround.is_hw102_image(os.path.join(REPO, "README.md")))

    @unittest.skipUnless(os.path.isfile(REPOSITORY_DUMP), "repository-linked dump is not present")
    def test_repository_dump_uses_its_own_exact_hash_and_sidecar(self):
        self.assertTrue(hw102_workaround.is_hw102_image(REPOSITORY_DUMP))
        sidecar = hw102_workaround.bundled_sidecar_for_image(REPOSITORY_DUMP)
        self.assertEqual(os.path.basename(sidecar), "dump202611220911.abs.json")
        contents = dump_catalog.otp(REPOSITORY_DUMP)
        self.assertEqual(contents[0x1C0], bytes.fromhex("15e857a6be62471248a852a3e886b8ed"))

    def test_profile_codes_make_the_validated_ext00_frames(self):
        expected = {
            10: (2, 16, 2), 11: (2, 17, 2), 12: (2, 11, 2), 13: (2, 14, 2),
            14: (2, 13, 2), 15: (2, 64, 2), 16: (2, 66, 2),
        }
        for vkey, frame in expected.items():
            with self.subTest(vkey=vkey):
                self.assertEqual(
                    ir_remote.frame_from_ir16(hw102_workaround.HW102_IR_KEY_TABLE[vkey], "ext00"),
                    frame,
                )

    def test_profile_installs_without_touching_the_gate(self):
        sim = FakeSim(HW102)
        gate = sim.mu.gp - hw102_workaround.HW102_GATE_GP_OFFSET
        sim.poke(gate, (0x2411E5D2).to_bytes(4, "little"))

        self.assertTrue(hw102_workaround.install_hw102_ir_profile(sim))

        self.assertEqual(sim.peek(gate, 4), (0x2411E5D2).to_bytes(4, "little"))
        self.assertEqual(sim._ir_key_table, hw102_workaround.HW102_IR_KEY_TABLE)
        self.assertEqual(sim.ir_coding, "ext00")

    def test_apply_sets_only_the_target_simulator_gate_and_key_table(self):
        sim = FakeSim(HW102)
        gate = sim.mu.gp - hw102_workaround.HW102_GATE_GP_OFFSET
        sim.poke(gate, (0x2411E5D2).to_bytes(4, "little"))

        result = hw102_workaround.apply_input_workaround(sim)

        self.assertTrue(result["ok"])
        self.assertEqual(result["gate_address"], gate)
        self.assertEqual(result["gate_before"], 0x2411E5D2)
        self.assertEqual(sim.peek(gate, 4), b"\0\0\0\0")
        self.assertEqual(sim._ir_key_table, hw102_workaround.HW102_IR_KEY_TABLE)

    def test_wrong_image_is_not_patched(self):
        sim = FakeSim(os.path.join(REPO, "README.md"))
        self.assertFalse(hw102_workaround.install_hw102_ir_profile(sim))
        self.assertIsNone(hw102_workaround.apply_input_workaround(sim))
        self.assertIsNone(sim._ir_key_table)

    def test_out_of_range_gp_gate_fails_closed(self):
        sim = FakeSim(HW102, gp=0x80000000)
        result = hw102_workaround.apply_input_workaround(sim)
        self.assertFalse(result["ok"])
        self.assertIn("outside guest RAM", result["reason"])

    def test_sidecar_contains_the_emulator_only_gate_record(self):
        contents = dump_catalog.otp(HW102)
        self.assertEqual(
            contents[0x1C0],
            bytes.fromhex("15e857a6be62471248a852a3e886b8ed"),
        )
        self.assertEqual(contents[0x210], bytes.fromhex("00005000"))


if __name__ == "__main__":
    unittest.main()
