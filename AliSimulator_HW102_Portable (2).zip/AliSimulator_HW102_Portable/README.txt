AliSimulator HW102 portable bundle
===================================

QUICK START (Windows 10/11)
---------------------------
1. Extract this ZIP to a normal folder (for example, Desktop\AliSimulator_HW102_Portable).
2. Install Python 3.10 or newer from https://www.python.org/downloads/windows/ if it is not already installed. Enable Tcl/Tk and the Python launcher in the installer.
3. Open Command Prompt in this folder and run:

       run_hw102.bat

The batch file creates a local .venv, installs the required Python packages the first time (internet access is needed once), and opens the TV interface with the GitHub-linked dump202611220911.abs. It selects the Unicorn engine; no C++ build is needed. The original HW102.02.999... image is also included and can be selected from the Dump dropdown.

Manual setup and launch:

       python -m pip install -r requirements.txt
       python src\tv_gui.py "dumps\dump202611220911.abs"

HW102 INPUT AND DISPLAY
-----------------------
The included dump202611220911.abs and HW102.02.999-V-5079-By-www.receiveroption.com.abs have different full-image SHA-1 hashes but byte-for-byte identical decompressed maincode. Both exact image files have sidecars in this bundle. The GUI matches these two files by SHA-1, installs the firmware-derived IR profile, and provides the matching emulator-only OTP record at offset 0x1C0. The firmware's own comparison then clears its input gate; the normal path does not write the gate in guest RAM.

If you browse to an exact copy of either image stored elsewhere and it has no adjacent JSON sidecar, the program finds the matching bundled sidecar automatically. The status line reports "bundled emulator-only OTP sidecar". The toolbar option "HW102 gate fallback (manual)" is available for these known images but remains unchecked by default; it is a legacy guest-RAM bypass, not the normal fix.

The 0x1C0 record is experimental emulator-only test provisioning derived from the firmware comparison. It is NOT a physical OTP dump. Hardware identity/provisioning remain unverified. The firmware-derived NEC mapping was tested in emulation only; no physical remote was tested.

With IR left on Auto, send RIGHT once to select the active 0x4040 remote profile, then send RIGHT again to move the visible menu selection. C3503 GMA layer-0 enable bit 0 is preserved only for chip ID 0x3503; C3507 is excluded. End-to-end validation covers these two containers of the same C3503C maincode, not other C3503 firmware or physical hardware.

For the trace summary, test commands, evidence, and limitations, see notes\HW102_input_fix.md. Current screen captures are in notes\hw102_input_fix_capture\.

FOCUSED TESTS
-------------
With dependencies installed, run from this folder:

       python tests\test_hw102_workaround.py
       python tests\test_c3503_gma.py
       python tests\test_hw102_input_fix.py

The two-image integration test takes about 80 seconds on the test environment.

CONTENTS
--------
src\                      AliSimulator application and simulator modules
dumps\                    Both image files and their experimental sidecar JSONs
run_hw102.bat              Windows setup-and-launch script
requirements.txt           Python packages installed into the local .venv
notes\                     Input-fix evidence and current screen captures
tests\                     Focused unit and two-container integration tests
