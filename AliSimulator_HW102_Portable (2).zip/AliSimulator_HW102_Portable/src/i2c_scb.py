"""
The ALi SoCs' hardware I2C masters ("SCB": 0xB8018200 and 0xB8018700 on the
M3801, 0xB8018B00 on the M3821, plus 0xB8018D00 as SCB3 on the C3505; the tuner,
an EEPROM and other board chips hang on them), as the firmware's driver uses them (dump.bin's application,
0x801B0A0C..0x801B14EC; the M3821 application is a "newer chip" to it and
writes +0x23 / +0x24):

  +0     control: bit 7 enable; a write with bit 0 set starts a transfer --
         0x41 a write of the FIFO's bytes, 0x45 a read, 0x49 a write of the
         sub-address at +5 (and +0x25.. on newer chips, +0x24 = how many more)
         followed by a read
  +1     status, cleared by writing 0: bits 7..5 = a transfer in progress (the
         driver waits for them to clear after a start, checking +3 for an error
         meanwhile, and for bit 5 to be clear before one), bit 1 = FIFO full;
         the model's transfers complete at once, so they always read clear
  +2     bits 3..0 cleared at init; +3 written 0x0F before a transfer and
         polled after it: bit 0 = complete, bits 3..1 = error -- the driver
         reads +3 & 0x0E as "no ACK" (-9), a +1 that never shows done as a
         timeout (-34) after 99 ms
  +4     the slave address byte (bit 0 = read), +5 the first data byte again
  +6..+B clock dividers (6 MHz / SCL), +0x14 bits 2..0 read 0 = bus idle
  +C     bit 7 FIFO enable | the transfer length (bits 4..0; bits 7..5 at
         +0x23 on newer chips), reading back as the number of received bytes
         waiting in the FIFO
  +0x10  the data FIFO: writes queue the bytes to send, reads pop received ones

A transfer completes the moment it is started.  The slaves are
sim.i2c_devices, {7-bit address: device} with device.write(data) -> bool (the
ACK) and device.read(n) -> bytes or None (no ACK); an address nobody answers
gets no ACK (the driver's -9) -- unless sim.i2c_ack_all is set, when every
address answers and reads return zeros, so a tuner driver runs its whole
register initialisation, which the log shows, with no model of the tuner.
RegisterSlave is the usual chip: a register file addressed by the first byte
written, auto-incrementing, read back from the address last written.
"""
import collections
import ctypes


class RegisterSlave:
    """A chip with 8-bit registers: a write sets the address (its first byte)
    and the data after it, a read returns registers from that address on."""
    def __init__(self, registers=None, size=256, fill=0x00):
        self.regs = bytearray([fill]) * size
        for address, value in (registers or {}).items():
            self.regs[address] = value
        self.address = 0

    def write(self, data):
        if data:
            self.address = data[0]
            for i, b in enumerate(data[1:]):
                self.regs[(self.address + i) % len(self.regs)] = b
        return True

    def read(self, n):
        out = bytes(self.regs[(self.address + i) % len(self.regs)] for i in range(n))
        self.address = (self.address + n) % len(self.regs)
        return out


class AckAll:
    """Answers at any address: writes acknowledged, reads give zeros."""
    def write(self, data):
        return True

    def read(self, n):
        return bytes(n)


class I2cMaster:
    """One SCB block; the simulator makes one per base in its I2C_SCB_BASES."""
    SIZE = 0x28
    LOG_FIRST, LOG_EVERY = 64, 256          # transactions logged: the first ones, then one in N
    IC_LINES = {0x18200: 18, 0x18700: 25, 0x18B00: 26, 0x18D00: 43}
    C3507_IC_LINES = {0x18200: 20, 0x18700: 21, 0x18B00: 25, 0x18D00: 26}
    SCB_SLOTS = {0x18200: 0, 0x18700: 1, 0x18B00: 2, 0x18D00: 3}

    def __init__(self, sim, base, name):
        self.sim, self.base, self.name = sim, base, name
        self._scb_slot = self.SCB_SLOTS.get(base, -1)
        self._cpp_active = False
        self._ic_line = self.IC_LINES.get(base)
        self.transactions = 0
        self.reset()
        sim._mmio_on('w', self._write, base, base + self.SIZE - 1)
        sim._mmio_on('r', self._read, base, base + self.SIZE - 1)

    @property
    def ic_line(self):
        return self._ic_line

    @ic_line.setter
    def ic_line(self, value):
        self._ic_line = value
        self._cpp_sync_config(reset=False)

    def _cpp_sync_config(self, reset=False):
        core = getattr(self.sim, "_core", None)
        if core is not None and self._scb_slot >= 0:
            import cpp_core
            line = -1 if self._ic_line is None else int(self._ic_line)
            cpp_core.lib().ali_scb_config(core.handle, self._scb_slot, line, 1 if reset else 0)

    def remove(self):
        self.sim._mmio_off('w', self._write, self.base, self.base + self.SIZE - 1)
        self.sim._mmio_off('r', self._read, self.base, self.base + self.SIZE - 1)

    def reset(self):
        self.tx = bytearray()               # queued for the next write
        self.rx = collections.deque()       # received, popped at +0x10
        self.control = 0                    # +0 (bit 0 start self-clears)
        self.status = 0                     # +1
        self.ier = 0                        # +2
        self.flags = 0                      # +3
        self.slave = 0                      # +4
        self.sub = bytearray(4)             # +5, +0x25..+0x27
        self.sub_extra = 0                  # +0x24
        self.length = 0                     # +C bits 4..0 | +0x23 << 5
        self.length_hi = 0
        self.ier1 = 0                       # +0x20
        self.isr1 = 0                       # +0x21
        self._irq_active = False
        self._cpp_sync_config(reset=True)

    def _sync_irq(self):
        if self.ic_line is not None:
            active = bool((self.flags & self.ier) or (self.isr1 & self.ier1))
            if active != self._irq_active:
                self._irq_active = active
                if hasattr(self.sim, "_ic_set_line"):
                    self.sim._ic_set_line(self.ic_line, active)

    def _write(self, uc, access, address, size, value, user_data):
        self.sim._device_access(uc)
        off = (address & 0xFFFFFF) - self.base
        for i in range(size):
            b, o = (value >> (8 * i)) & 0xFF, off + i
            if o == 0x00:
                self.control = b & ~0x01
                if b & 0x01:
                    self._transfer(b)
            elif o == 0x01:
                self.status = 0 if b == 0 else self.status & ~b
            elif o == 0x02:
                self.ier = b
                self._sync_irq()
            elif o == 0x03:
                self.flags &= ~b
                self._sync_irq()
            elif o == 0x04:
                self.slave = b
            elif o == 0x05:
                self.sub[0] = b
            elif o == 0x0C:
                self.length = b & 0x1F
                if not b & 0x80:
                    self.tx.clear()
                    self.rx.clear()
            elif o == 0x10:
                self.tx.append(b)
            elif o == 0x20:
                self.ier1 = b
                self._sync_irq()
            elif o == 0x21:
                self.isr1 &= ~b
                self._sync_irq()
            elif o == 0x23:
                self.length_hi = b
            elif o == 0x24:
                self.sub_extra = b & 3
            elif 0x25 <= o <= 0x27:
                self.sub[o - 0x24] = b

    def _read_byte(self, o):
        if o == 0x00:
            return self.control
        if o == 0x01:
            return self.status | (0x01 if (self.ier or self.ier1) and not self.rx else 0x00)
        if o == 0x02:
            return self.ier
        if o == 0x03:
            return self.flags
        if o == 0x0C:
            return 0x80 | min(len(self.rx), 0x1F)
        if o == 0x10:
            return self.rx.popleft() if self.rx else 0xFF
        if o == 0x14:
            return 0
        if o == 0x20:
            return self.ier1
        if o == 0x21:
            return self.isr1
        return None

    def _read(self, uc, access, address, size, value, user_data):
        self.sim._device_access(uc)
        base_off = address & 0xFFFFFF
        off = base_off - self.base
        view = getattr(self.sim, "_mmio_view", None)
        if view is not None:
            for i in range(size):
                val = self._read_byte(off + i)
                if val is not None:
                    view[base_off + i] = val
        else:
            buf = bytearray(uc.mem_read(address, size))
            for i in range(size):
                val = self._read_byte(off + i)
                if val is not None:
                    buf[i] = val
            uc.mem_write(address, bytes(buf))

    def _transfer(self, control):
        sim = self.sim
        core = getattr(sim, "_core", None) if self._cpp_active else None
        if core is not None:
            import cpp_core
            L = cpp_core.lib()
            meta = (ctypes.c_uint8 * 8)()
            tx_buf = (ctypes.c_uint8 * 256)()
            tx_len = L.ali_scb_pull_tx(core.handle, self._scb_slot, meta, tx_buf)
            self.slave = meta[0]
            self.length = meta[1]
            self.length_hi = meta[2]
            self.sub[0] = meta[3]
            self.sub[1] = meta[4]
            self.sub[2] = meta[5]
            self.sub[3] = meta[6]
            self.sub_extra = meta[7]
            self.tx = bytearray(bytes(tx_buf)[:tx_len])
        read, combined = bool(control & 0x04), bool(control & 0x08)
        addr7 = self.slave >> 1
        n = self.length | (self.length_hi << 5)
        device = sim.i2c_devices.get(addr7) or (AckAll() if sim.i2c_ack_all else None)
        sent, got, ack = b"", b"", False
        if combined:
            sent = bytes(self.sub[:1 + self.sub_extra])
            ack = bool(device) and device.write(sent)
            if ack:
                got = device.read(n)
                ack = got is not None
        elif read:
            got = device.read(n) if device else None
            ack = got is not None
        else:
            sent = bytes(self.tx)
            ack = bool(device) and device.write(sent)
        self.tx.clear()
        if ack and (read or combined):
            got = (got or b"")[:n] + bytes(max(0, n - len(got or b"")))
            if core is None:
                self.rx.extend(got)
        self.flags = 0x01 if ack else 0x02          # (+1 stays clear: the transfer is over)
        self.isr1 = 0x01 if ack else 0x00
        if core is not None:
            rx_bytes = got if (ack and (read or combined)) else b""
            L.ali_scb_push_rx(core.handle, self._scb_slot, rx_bytes, len(rx_bytes), self.flags, self.isr1)
        else:
            self._sync_irq()
        self.transactions += 1
        if self.transactions <= self.LOG_FIRST or self.transactions % self.LOG_EVERY == 0:
            what = "W" if not (read or combined) else ("WR" if combined else "R")
            sim.log(f"[I2C] {self.name} {what} 0x{addr7:02X}" + ("" if ack else " (no ACK)")
                    + (": " + sent.hex(" ") if sent else "") + (f" -> {bytes(got).hex(' ')}" if got else ""))
