"""
The simulator on the C++ core (engine 'cpp'): AliMipsSimulator(engine='cpp'),
or every simulator a process makes with ALISIM_ENGINE=cpp in the environment
(python run_all_tests.py --engine cpp).

What stays the same: every device model, chip family and API of
simulator.AliMipsSimulator -- the device register handlers (_mmio_on), the SPI
flash, the GE, the IR controller, the panels, the SEE's second core, press_key,
capture_screen, run(), step(), sim.mu (the core seen through Unicorn's Python
API, cpp_core.CppUc).  What the core does instead of Unicorn and the Python
hooks around it:

  * CP0 natively (Count / Compare, Status, Cause, EPC, EBase, ERET): no CP0
    instruction sites to scan and hook, no slice stopper, no replayed device
    accesses (a stop ends the instruction cleanly), no forced ERL or TLB trick
    (kuseg is 1:1);
  * interrupts -- the timer, the interrupt controller's lines and doorbells,
    the UART receive interrupt -- at the exact instruction they become
    deliverable (never in a delay slot), as the exact mode did;
  * the clock: emulation time is the instruction count, cpp_ips instructions
    per emulated second (deterministic, whatever the host does); Count runs at
    count_hz of it (with the defaults 2 Count ticks per instruction, the exact
    mode's rate);
  * idle loops (`b .` / nop, MIPS16 `b .`, WAIT) skip to the next event;
  * the device window's registers without a handler are read and written by
    the core itself; those with one call the Python handler (_mmio_read /
    _mmio_write), as an mmio_map callback did.

instruction_count keeps the Python engine's meaning, so the tests' budgets
mean what they did: exact while the first counted slices run (small budgets,
the start-up), then emulation time at _insn_rate (cpp_rate).
"""
import ctypes
import os
import struct
import sys
import threading
import zlib

from uc_const import (UcError, UC_HOOK_CODE, UC_HOOK_MEM_UNMAPPED, UC_HOOK_MEM_FETCH_PROT,
                      UC_HOOK_MEM_READ_PROT, UC_HOOK_MEM_WRITE_PROT, UC_PROT_ALL,
                      UC_MIPS_REG_PC, UC_MIPS_REG_SP)

import cpp_core
from cpp_core import (F_ICOUNT, F_EXECUTED, F_STATUS, F_CAUSE, F_CAUSE_VALUE, F_EPC, F_EBASE, F_COMPARE, F_COUNT,
                      F_TI, F_TIMER_ARMED, F_TIMER_ENABLED, F_TIMER_IRQS, F_IC_IRQS, F_IC_LINES, F_IC_LINES_HI,
                      F_UART_IP3, F_UART_PENDING, F_UART_DELIVERED, F_UART_AT, F_UART_FORCE, F_IDLE_SKIP, F_EXACT,
                      F_IRQS_ENABLED, F_M16, F_DS_ACTIVE, F_IDLE_SKIPPED, F_FAULT_PC, F_FAULT_ADDR,
                      F_STEP_OVER_BP, F_IRQ_DELIVERABLE, F_IC_IP3, F_TIMER_ANCHOR, F_LAST_ERROR,
                      F_PC_MODE, F_COUNT_OBSERVED, F_COUNT_OBSERVED_VALID, F_COUNT_RAW_WRITE,
                      F_COMPARE_WRITE, F_DEMOD_LOCKED, F_DEMOD_READS, F_GE_IC_LINE, F_GE_M3602_CMDS,
                      STOP_ERROR, STOP_BREAKPOINT, STOP_REQUEST,
                      STOP_COUNT, EVT_UART_ERET, EVT_CODE_CHUNK, EVT_FLASH_READ, EVT_UART_IRQ, DF_READ, DF_WRITE,
                      DF_GPIO_DI, DF_GPIO_DO, DF_GPIO_DIR, DF_IC_STATUS, DF_GE, F_UART_IRQS,
                      DR_READ, DR_WRITE, DR_UART_IDLE, DR_WRITE_IGNORE, DR_VPO, DR_SCB, DR_UART_TX,
                      RULE_DEMOD, RULE_DEMOD_COUNT, RULE_DEMOD_CLR3F, RULE_DEMOD_IFZERO,
                      RULE_EXACT_OFF, RULE_VE_STATUS, RULE_MAC_MDIO,
                      RULE_VPO_WRITE, RULE_VPO_M36F_WRITE, RULE_VE_STATUS_WRITE,
                      RULE_GE3602_WRITE, RULE_OSD_PAL_WRITE, RULE_MIRROR, RULE_DDR_TRAINING,
                      RULE_SDRAM_CMD, RULE_TRNG_WRITE)
from simulator import AliMipsSimulator, ISAMode


class _MmioRule(ctypes.Structure):
    _fields_ = [
        ("offset", ctypes.c_uint32),
        ("req_mask", ctypes.c_uint8),
        ("and_mask", ctypes.c_uint8),
        ("or_mask", ctypes.c_uint8),
        ("pad", ctypes.c_uint8),
        ("flags", ctypes.c_uint32),
    ]

DEFAULT_IPS = int(float(os.environ.get("ALISIM_CPP_IPS", "50e6")))     # instructions per emulated second
# instruction_count per emulated second in fast mode: what the Unicorn engine calibrates
# on this machine (~0.76 M/s), so a test's instruction budget is the same emulated time
DEFAULT_RATE = float(os.environ.get("ALISIM_CPP_RATE", "0.75e6"))
# emulated time a device register access handled in Python costs, in instructions: a
# poll loop on such a register (waiting for the RTC's next second, say) must see time
# pass -- the Unicorn engine charged the handler's host time, ~5 us
DEFAULT_ACCESS_COST = int(os.environ.get("ALISIM_CPP_ACCESS_COST", "250"))


# the native SPI controller's state (ali_spi_get / ali_spi_set)
(S_INS, S_FMT, S_DUM, S_CFG, S_STATUS, S_WEL, S_RESP_LEN, S_RESP_IDX, S_ON, S_COMMANDS,
 S_RESP0, S_RESP1, S_RESP2, S_RESP3, S_PROGRAMS, S_ERASES) = range(1, 17)
SPI_REGS = tuple(base + i for base in (0x00098, 0x2E098) for i in range(4))


def _spi_prop(field, doc, bool_=False):
    def get(self):
        v = cpp_core.lib().ali_spi_get(self._core.handle, field)
        return bool(v) if bool_ else v

    def set_(self, value):
        cpp_core.lib().ali_spi_set(self._core.handle, field, int(value) & 0xFF)
    return property(get, set_, doc=doc)


def _cpu_prop(field, doc, bool_=False):
    def get(self):
        v = self._core.get(field)
        return bool(v) if bool_ else v

    def set_(self, value):
        self._core.set(field, int(bool(value)) if bool_ else int(value) & 0xFFFFFFFFFFFFFFFF)
    return property(get, set_, doc=doc)


class _SimUc(cpp_core.CppUc):
    """sim.mu: the core's Unicorn-like API, with the simulator's bookkeeping
    around emu_start / emu_stop (as the Unicorn engine's wrappers did)."""

    def __init__(self, sim):
        super().__init__()
        self._sim = sim

    def emu_start(self, begin, until, timeout=0, count=0):
        sim = self._sim
        sim._cpp_sync()
        sim._stop_reason = None
        e0 = self.get(F_EXECUTED)
        try:
            super().emu_start(begin, until, timeout, count)
        finally:
            sim._cpp_after_start(self.get(F_EXECUTED) - e0)

    def emu_stop(self):
        sim = self._sim
        if sim._stop_reason is None:
            sim._stop_reason = 'external'
        if sim._in_run and threading.get_ident() != sim._run_tid:
            sim._external_stop = True       # a pause from another thread (GUI): run() returns
        super().emu_stop()


class CppAliMipsSimulator(AliMipsSimulator):
    engine = "cpp"
    native_status = True
    force_erl = False
    delay_hle = os.environ.get("ALISIM_CPP_DELAY_HLE", "0") == "1"   # (Python hooks: slower than the core running the loops)
    # A timed slice runs the timer interrupts in the core (it does not end at each
    # one, as the Unicorn engine's do): a slice service with a due() -- the
    # emulation time it next has work at -- ends the slice there instead, but
    # never sooner than this after its start
    SERVICE_MIN_SLICE_S = 0.0005
    skip_irq_disable = False

    # the CPU state the core keeps (the Python engine's shadow attributes)
    cp0_status = _cpu_prop(F_STATUS, "CP0 Status (the guest's)")
    cp0_cause = _cpu_prop(F_CAUSE, "CP0 Cause's stored bits (cause_value() adds the lines)")
    cp0_epc = _cpu_prop(F_EPC, "CP0 EPC")
    cp0_ebase = _cpu_prop(F_EBASE, "CP0 EBase")
    cp0_compare = _cpu_prop(F_COMPARE, "CP0 Compare (raw)")
    timer_irq_count = _cpu_prop(F_TIMER_IRQS, "timer interrupts delivered")
    ic_irq_count = _cpu_prop(F_IC_IRQS, "interrupt-controller interrupts delivered")
    _ti = _cpu_prop(F_TI, "Cause.TI latched", True)
    _timer_armed = _cpu_prop(F_TIMER_ARMED, "a Compare was written", True)
    _timer_anchor = _cpu_prop(F_TIMER_ANCHOR, "Count of the last crossing check")
    _uart_ip3 = _cpu_prop(F_UART_IP3, "IP3 of a delivered UART interrupt", True)
    _pending_uart_irq = _cpu_prop(F_UART_PENDING, "UART receive interrupt armed", True)
    _uart_irq_delivered = _cpu_prop(F_UART_DELIVERED, "... and delivered", True)
    _uart_irq_force = _cpu_prop(F_UART_FORCE, "... whatever Status says", True)
    _uart_irq_retries = _cpu_prop(F_UART_IRQS, "UART receive interrupts delivered")
    ge_ops = _cpu_prop(cpp_core.F_GE_OPS, "GE commands executed")
    _ge_status = _cpu_prop(cpp_core.F_GE_STATUS, "GE interrupt status")
    ge_render = _cpu_prop(cpp_core.F_GE_RENDER, "execute GE commands", True)
    # the SPI flash controller's state lives in the core (its native model and the
    # Python one, _hook_spi_*, share it)
    _spi_ins = _spi_prop(S_INS, "SF_INS")
    _spi_fmt = _spi_prop(S_FMT, "SF_FMT")
    _spi_dum = _spi_prop(S_DUM, "SF_DUM")
    _spi_cfg = _spi_prop(S_CFG, "SF_CFG")
    _spi_status = _spi_prop(S_STATUS, "the part's status register")
    _spi_wel = _spi_prop(S_WEL, "its write-enable latch", True)
    _spi_resp_idx = _spi_prop(S_RESP_IDX, "the next response byte")

    @property
    def _spi_response(self):
        L, h = cpp_core.lib(), self._core.handle
        return [L.ali_spi_get(h, S_RESP0 + i) for i in range(L.ali_spi_get(h, S_RESP_LEN))]

    @_spi_response.setter
    def _spi_response(self, value):
        L, h = cpp_core.lib(), self._core.handle
        value = list(value)[:4]
        for i, b in enumerate(value):
            L.ali_spi_set(h, S_RESP0 + i, b)
        L.ali_spi_set(h, S_RESP_LEN, len(value))

    def _spi_native_wanted(self):
        """Whether the core's own SPI controller serves the firmware: not while the
        Python model is needed -- SPI logging, a family's byte-stream mode of the
        window (the M3821's, while active), a parallel flash, an observer on its registers."""
        return (not self._spi_dump_enabled and not self._spi_dump_flash_reads
                and (self._spi_stream is None or not self._spi_stream.active)
                and self.flash_device is None and getattr(self, "spi_native", True)
                and not any(lo <= off <= hi for _w, lo, hi, _cb in self._mmio_observers for off in SPI_REGS))

    def _cpp_spi_sync(self):
        """The native SPI controller on / off, on the current flash image."""
        want = self._spi_native_wanted()
        image = self.rom_image
        key = (want, id(image), len(image))
        if key == self.__dict__.get('_spi_key'):
            return
        self._spi_key = key
        if self._rom_dirty:
            self._rom_restore()
        if want:
            self._rom_image_ref = (ctypes.c_char * len(image)).from_buffer(image)     # (keeps it alive, fixed size)
            img_ptr = ctypes.addressof(self._rom_image_ref)
        else:
            self._rom_image_ref, img_ptr = None, None
        jedec = (self._spi_jedec_id[0] << 16) | (self._spi_jedec_id[1] << 8) | self._spi_jedec_id[2]
        cpp_core.lib().ali_spi_config(self._core.handle, int(want), ctypes.addressof(self.rom_buffer), img_ptr,
                                      self.rom_size, jedec)
        self._update_flash_read_hooks()
        self._dev_sig = None            # (the registers' flags change)

    def __init__(self, *args, **kwargs):
        shared = kwargs.get("share_memory_with")
        self._core = _SimUc(self)
        self._mmio_version = 0
        self._dev_pushed = {}           # offset -> flags pushed to the core
        self._dev_sig = None
        self._bp_pushed = None
        self._flash_cmd_on = False
        self._uart_arm_units = 0
        self._doorbell = None
        self._exact_hook = None
        self.cpp_ips = DEFAULT_IPS
        self._count_hz_v = 100_000_000
        self._cb_keep = []
        self._gi2c_bus = None           # the gpio_i2c.GpioI2cBus the core runs (_cpp_gpio_sync)
        self._gi2c_cb = None
        self._tm1650_dec = None         # the tm1650_decoder.TM1650Decoder the core runs (_cpp_gpio_sync)
        self._tm1650_cb = None
        self._tm1628_dec = None         # the tm1628_decoder.TM1628Decoder the core runs (_cpp_gpio_sync)
        self._tm1628_cb = None
        self._hc164_dec = None          # the hc164_decoder.HC164Decoder the core runs (_cpp_gpio_sync)
        self._hc164_cb = None
        self._lemontree_dec = None      # the lemontree_decoder.LemontreeDecoder the core runs (_cpp_gpio_sync)
        self._lemontree_cb = None
        self._gpio_sync_key = None
        self._gpio_watch_pushed = None
        self._gpio_di_high_pushed = None
        self._gpio_di_busy_pushed = None
        self._gpio_di_owners = ()
        self._demod_locked_pushed = None
        self._idle_skip_pushed = None
        self._dev_rules_pushed = None
        super().__init__(*args, **kwargs)
        self._insn_rate = DEFAULT_RATE
        self._apply_count_ratio()
        self._core.set(cpp_core.F_HOST_ACCESS_COST, DEFAULT_ACCESS_COST)
        self._hflags_off = 0            # (the ISA mode is the core's: is_mips16_mode)
        if os.environ.get("ALISIM_CPP_PROFILE"):
            import atexit
            self._core.prof(True)
            atexit.register(self._prof_report, os.environ["ALISIM_CPP_PROFILE"])

    def _prof_report(self, dest, n=30):
        """ALISIM_CPP_PROFILE=<file> (or 1: stderr): at exit, where the core ran
        (instructions per block start) and which instructions' device accesses
        went to Python, with their code."""
        import sys
        from mips16_decoder import MIPS16Decoder
        core = self._core
        out = [f"--- core {id(self) & 0xFFFF:04x}: {core.get(F_EXECUTED):,} instructions executed, "
               f"skipped: idle {core.get(F_IDLE_SKIPPED):,}, spin {core.get(cpp_core.F_SPIN_SKIPPED):,}, "
               f"Count polls {core.get(cpp_core.F_POLL_SKIPPED):,} ({core.get(cpp_core.F_POLL_SKIPS):,} loops); "
               f"counting loops {core.get(cpp_core.F_FF_SKIPPED):,}; "
               f"blocks {core.get(cpp_core.F_BLOCK_RUNS):,} runs, {core.get(cpp_core.F_BLOCK_BUILDS):,} builds"]
        for which, title in ((0, "instructions run, per block start"),
                             (1, "device accesses handled in Python, per instruction")):
            top = self._core.prof_top(which, n)
            total = sum(c for _, c in top) or 1
            out.append(f"--- {self.chip_name if hasattr(self, 'chip_name') else ''} core "
                       f"{id(self) & 0xFFFF:04x}, icount {self._core.get(F_ICOUNT):,}: {title} (top {len(top)})")
            for key, count in top:
                pc, m16 = key & ~1, key & 1
                try:
                    code = bytes(self.mu.mem_read(pc, 4))
                    if m16:
                        sz16 = 4 if len(code) >= 2 and (code[1] & 0xF8) in (0xF0, 0x18) else 2
                        mn, ops = MIPS16Decoder.decode(code[:sz16], pc)
                        text = f"{mn} {ops}"
                    else:
                        i = next(self.md.disasm(code, pc), None) if self.md else None
                        text = f"{i.mnemonic} {i.op_str}" if i else code.hex()
                except Exception:
                    text = "?"
                out.append(f"  {pc:08X}{'m' if m16 else ' '} {count:14,} {100 * count / total:5.1f}%  {text}")
                if which == 0 and not m16 and self.md and os.environ.get("ALISIM_CPP_PROFILE_CODE") and \
                        count * 20 > total:
                    try:                    # (a hot block's code: ALISIM_CPP_PROFILE_CODE=1)
                        for i in self.md.disasm(bytes(self.mu.mem_read(pc, 48)), pc):
                            out.append(f"      {i.address:08X}  {i.mnemonic} {i.op_str}")
                    except Exception:
                        pass
        text = "\n".join(out) + "\n"
        if dest == "1":
            sys.stderr.write(text)
        else:
            with open(dest, "a", encoding="utf-8") as f:
                f.write(text)

    # ------------------------------------------------------------------
    # The machine on the core
    # ------------------------------------------------------------------
    def _init_unicorn(self):
        core = self.mu = self._core
        self.rom_buffer = self._buffer('rom_buffer', self.rom_size)
        self._rom_view = memoryview(self.rom_buffer).cast('B')
        self._spi_status_injected = False
        slot = min(self.rom_size, 0x400000)
        flash_phys = (0x1F000000,) if self._upper_ram_mapped else (0x0F000000, 0x1F000000)
        for offset in range(0, 0x01000000, slot):
            for phys in flash_phys:
                for seg in (0x00000000, 0x80000000, 0xA0000000):
                    self._map_flash_mirror(seg + phys + offset, slot)
        self._map_flash_linear_tail()
        self.ram_buffer = self._buffer('ram_buffer', self.ram_size)
        ram_ptr = ctypes.addressof(self.ram_buffer)
        low_ram = min(self.ram_size, 0x0F000000)
        for base in (0x80000000, 0xA0000000, 0x00000000):
            core.mem_map_ptr(base, low_ram, UC_PROT_ALL, ram_ptr)
        if self._upper_ram_mapped and self.ram_size > 0x0F000000:
            upper_sz = min(self.ram_size, 0x10000000) - 0x0F000000
            for seg in (0x80000000, 0xA0000000, 0x00000000):
                core.mem_map_ptr(seg + 0x0F000000, upper_sz, UC_PROT_ALL, ram_ptr + 0x0F000000)
        self._init_fast_access()
        self.force_erl = False
        self._site_words = set()
        self._site_word_array = None
        MMIO_SIZE = 0x01000000
        self.mmio_buffer = self._buffer('mmio_buffer', MMIO_SIZE)
        self._mmio_view = memoryview(self.mmio_buffer).cast('B')
        self._mmio_words = self._mmio_view.cast('I') if sys.byteorder == 'little' else None
        self._mmio_halfwords = self._mmio_view.cast('H') if sys.byteorder == 'little' else None
        mmio_ptr = ctypes.addressof(self.mmio_buffer)
        self._mmio_rd = {}
        self._mmio_wr = {}
        for base in (0x98000000, 0xB8000000):
            core.mem_map_ptr(base, MMIO_SIZE, UC_PROT_ALL, mmio_ptr)
        # the physical window: the core's own device window, the handlers through _cpp_dev
        L = cpp_core.lib()
        self._dev_cb = cpp_core._DEV_CB(self._cpp_dev)
        L.ali_set_device_window(core.handle, 0x18000000, mmio_ptr, MMIO_SIZE,
                                ctypes.cast(self._dev_cb, ctypes.c_void_p), None)
        core._map_changed()
        self._evt_cb = cpp_core._MACHINE_EVENT(self._cpp_event)
        L.ali_set_event_cb(core.handle, ctypes.cast(self._evt_cb, ctypes.c_void_p), None)
        self._gpio_cb = cpp_core._GPIO_CB(self._cpp_gpio)
        L.ali_set_gpio_cb(core.handle, ctypes.cast(self._gpio_cb, ctypes.c_void_p), None)
        count, pairs = ctypes.c_void_p(), ctypes.c_void_p()
        L.ali_gpio_log(core.handle, 1, ctypes.byref(count), ctypes.byref(pairs))   # (_cpp_dev empties it)
        self._gpio_count = (ctypes.c_uint32 * 1).from_address(count.value)
        self._gpio_pairs = (ctypes.c_uint32 * (2 * 4096)).from_address(pairs.value)
        self._utx_cb = cpp_core._UART_TX_CB(self._cpp_uart_tx)
        L.ali_uart_tx_callback(core.handle, ctypes.cast(self._utx_cb, ctypes.c_void_p), None)
        if self._shared is None:
            core.mem_write(0xB8018305, b'\x60')
        core.hook_add(UC_HOOK_MEM_UNMAPPED | UC_HOOK_MEM_FETCH_PROT | UC_HOOK_MEM_READ_PROT, self._hook_mem_invalid)
        core.hook_add(UC_HOOK_MEM_WRITE_PROT, self._hook_flash_write_prot)
        self._mmio_on('w', self._hook_uart_write, 0x18300, 0x18305)
        self._mmio_on('r', self._hook_uart_read, 0x18300, 0x18312)
        for gpio_off in self._GPIO_DO_OFFSETS:
            self._mmio_on('w', self._hook_gpio_write, gpio_off, gpio_off + 7)
        for di_off in self._GPIO_DI_TO_DO:
            self._mmio_on('r', self._hook_gpio_di_read, di_off, di_off + 3)
        for reg in self._SELF_COMPLETING:
            self._mmio_on('r', self._hook_selfcomplete_read, reg & ~3, reg)
        for reg in self._VE_STATUS_REGS:
            self._mmio_on('r', self._hook_ve_status_read, reg, reg + 3)
        self._mmio_on('w', self._hook_chip_id_store, 0x0000, 0x0003)
        self._mmio_on('w', self._hook_ge_write, 0xA004, 0xA00B)
        self._mmio_on('r', self._hook_ge_read, 0xA008, 0xA00B)
        self._mmio_on('r', self._hook_ic_status_read, self.ic_base, self.ic_base + 7)
        self._mmio_on('r', self._hook_mac_reset_read, 0x2C000, 0x2C000)
        self._mmio_on('r', self._hook_mac_mdio_read, 0x2C07C, 0x2C07F)
        self._mmio_on('r', self._hook_irc_read, 0x18101, 0x18101)
        self._mmio_on('r', self._hook_irc_read, 0x18107, 0x18108)
        self._mmio_on('w', self._hook_irc_write, 0x18107, 0x18107)
        for base in (0x00098, 0x2E098):
            self._mmio_on('w', self._hook_spi_write, base, base + 3)
            self._mmio_on('r', self._hook_spi_read, base, base + 3)
            if self._shared is None:
                self._mmio_view[base:base + 4] = b'\x03\x0d\x00\x00'
        import i2c_scb
        import smc_m36
        self.i2c_devices = self._shared.i2c_devices if self._shared else {}
        self.i2c_ack_all = False
        self._demod_address = None
        self.i2c_masters = [i2c_scb.I2cMaster(self, base, f"SCB{i}") for i, base in enumerate(self.I2C_SCB_BASES)]
        self.smc = smc_m36.SmartCard(self)
        self._flash_windows = [0x1F000000] if self._upper_ram_mapped else [0x0F000000, 0x1F000000]
        self.flash_device = None
        self._flash_read_hooks = []
        self._flash_hooks_pending = False
        self._spi_cmd_vt = -1e9
        self._spi_dump_flash_reads = False
        self.flash_hook_changes = 0
        self._mmio_observers = []
        wins = (ctypes.c_uint32 * len(self._flash_windows))(*self._flash_windows)
        L.ali_set_flash_cmd(core.handle, 0, wins, len(self._flash_windows))
        self._update_flash_read_hooks()
        core.hook_add(UC_HOOK_CODE, self._hook_null_jump, begin=0, end=3)
        self._short_block_hook = None
        self._short_block_hooks = {}
        self._long_block_hooks = {}
        self._orig_emu_stop = cpp_core.CppUc.emu_stop.__get__(core)
        # the core's interrupt controller (EBase and Status: the shadow attributes, set before)
        L.ali_set_ic(core.handle, self.ic_base, self.ic_base + 8, self.ic_base)
        if self._shared is not None and hasattr(self._shared, '_core'):
            L.ali_set_peer_core(core.handle, self._shared._core.handle)
        # first-execution reports of the RAM's 1 MB chunks (LzmaDecode found in new code)
        L.ali_set_chunks(core.handle, 20, min(self.ram_size, 0x10000000) >> 20)
        L.ali_ge_config(core.handle, ram_ptr, self.ram_size)

    def _calibrate_hflags(self):
        pass

    def _setup_kuseg_tlb(self):
        return True

    def _write_native_status(self, uc, val):
        self._core.set(F_STATUS, val)

    # ---- the device window: which offsets need the Python handlers ----
    def _mmio_on(self, kind, handler, begin, end):
        super()._mmio_on(kind, handler, begin, end)
        self._mmio_version += 1

    def _mmio_off(self, kind, handler, begin, end):
        super()._mmio_off(kind, handler, begin, end)
        self._mmio_version += 1

    def add_mmio_hook(self, kind, callback, begin, end):
        h = super().add_mmio_hook(kind, callback, begin, end)
        self._mmio_version += 1
        return h

    def remove_mmio_hook(self, handle):
        super().remove_mmio_hook(handle)
        self._mmio_version += 1

    def _switch_family(self, family):
        super()._switch_family(family)
        self._core.set(F_DEMOD_READS, 0)
        self._mmio_version += 1

    def _cpp_dev_flags(self):
        """The device window offsets whose accesses go to Python, and how."""
        L, h = cpp_core.lib(), self._core.handle
        native_spi = bool(L.ali_spi_get(h, S_ON))
        ge_obj = getattr(self, 'ge', None)
        native_ge = ge_obj is None or (ge_obj.fast_paths and ge_obj.trace is None)
        uart_idle = len(self._uart_rx_queue) == 0 and not self._dev_replays
        ve_status = bool(getattr(self.chip, 've_status', True))
        smc = getattr(self, 'smc', None)
        smc_idle = (smc is not None and not smc.inserted and not smc.rx_fifo and not smc.tx_buf
                    and smc.isr0 == 0 and smc.isr1 == 0)
        dmx_attr = getattr(self.chip, 'dmx', None)
        if isinstance(dmx_attr, (list, tuple)):
            dmx_list = dmx_attr
        else:
            dmx_list = tuple(d for d in (dmx_attr, getattr(self.chip, 'dmx1', None), getattr(self.chip, 'dmx2', None)) if d is not None)
        dmx_idle = tuple(d.mux is None and d.status == 0 and not any(d.write_ptr) for d in dmx_list)
        u2 = getattr(self.chip, 'uart2', None)
        u2_idle = u2 is not None and not u2.rx_queue and not self._dev_replays
        uart_tx = bool(getattr(self, 'uart_tx_native', False)) and self._shared is None and not self._dev_replays
        sig = (self._mmio_version, id(self._mmio_rd), len(self._mmio_rd), id(self._mmio_wr), len(self._mmio_wr),
               len(self._mmio_observers), native_spi, native_ge, uart_idle, ve_status, smc_idle, dmx_idle, u2_idle,
               uart_tx)
        if sig == self._dev_sig:
            return
        self._dev_sig = sig
        want = {}
        for off in self._mmio_rd:
            want[off] = want.get(off, 0) | DF_READ
        for off in self._mmio_wr:
            want[off] = want.get(off, 0) | DF_WRITE
        rd_obs = set()
        wr_obs = set()
        for write, lo, hi, _cb in self._mmio_observers:
            bit = DF_WRITE if write else DF_READ
            obs_set = wr_obs if write else rd_obs
            for off in range(lo, hi + 1):
                want[off] = want.get(off, 0) | bit
                obs_set.add(off)
        if native_spi:
            spi_read, spi_write = self._hook_spi_read, self._hook_spi_write
            for off in SPI_REGS:
                if self._mmio_rd.get(off) == [spi_read] and self._mmio_wr.get(off) == [spi_write]:
                    want[off] = 8           # (Core::DF_NATIVE)
        # GPIO DO / DIR stores whose only handler is _hook_gpio_write: the core logs
        # the pin levels after each and hands them over in order (_cpp_gpio)
        gpio_write = self._hook_gpio_write
        for off, handlers in self._mmio_wr.items():
            if handlers == [gpio_write] and not (want[off] & DF_READ) and off not in wr_obs:
                want[off] = DF_GPIO_DO if (off & ~3 & 0xFFF) in self._GPIO_DO_OFFSETS else DF_GPIO_DIR
        gpio_di_read = self._hook_gpio_di_read
        for off, handlers in self._mmio_rd.items():
            di_base = off & ~3 & 0xFFF
            if handlers == [gpio_di_read] and not (want[off] & DF_WRITE) and \
                    self._GPIO_DI_TO_DO.get(di_base) == di_base + 4 and \
                    self._GPIO_DI_TO_DIR.get(di_base) == di_base + 8 and off not in rd_obs:
                want[off] = DF_GPIO_DI
        ic_read = self._hook_ic_status_read
        for off, handlers in self._mmio_rd.items():
            if handlers == [ic_read] and off not in rd_obs:
                want[off] = (want.get(off, 0) & ~DF_READ) | DF_IC_STATUS
        if native_ge and all(self._mmio_wr.get(o) == [self._hook_ge_write] for o in range(0xA004, 0xA00C)) and \
                all(self._mmio_rd.get(o) == [self._hook_ge_read] for o in range(0xA008, 0xA00C)) and \
                not any(lo <= 0xA00B and 0xA004 <= hi for _w, lo, hi, _cb in self._mmio_observers):
            for o in range(0xA004, 0xA00C):
                want[o] = want.get(o, 0) | DF_GE
        changes = [(off, f) for off, f in want.items() if self._dev_pushed.get(off) != f]
        changes += [(off, 0) for off in self._dev_pushed if off not in want]
        if changes:
            n = len(changes)
            offs = (ctypes.c_uint32 * n)(*[c[0] for c in changes])
            flags = (ctypes.c_uint8 * n)(*[c[1] for c in changes])
            L.ali_set_dev_flags_list(h, offs, flags, n)
        self._dev_pushed = want

        # Native C++ MMIO status/bit rules (devrules_ + mmio_rules_)
        from chips.base import DemodulatorLock, ReadyBits
        rflags = {}
        rules = []
        seen_selfcomp = False
        seen_mac_rst = False
        seen_ready = []
        seen_demod_lock = []
        seen_idemod = []
        seen_mirrors = []
        seen_ddr_tr = False
        sc_read = self._hook_selfcomplete_read
        mac_rst = self._hook_mac_reset_read
        mac_mdio = self._hook_mac_mdio_read
        ve_read = self._hook_ve_status_read
        uart_read = self._hook_uart_read
        for off, handlers in self._mmio_rd.items():
            if len(handlers) != 1 or off in rd_obs or not (want.get(off, 0) & DF_READ):
                continue
            fn = handlers[0]
            if fn == sc_read:
                rflags[off] = rflags.get(off, 0) | DR_READ
                seen_selfcomp = True
            elif fn == mac_rst:
                rflags[off] = rflags.get(off, 0) | DR_READ
                seen_mac_rst = True
            elif fn == mac_mdio:
                rflags[off] = rflags.get(off, 0) | DR_READ
                rules.append((off, 0, 0xFF, 0, 0, RULE_EXACT_OFF | RULE_MAC_MDIO))
            elif fn == ve_read:
                rflags[off] = rflags.get(off, 0) | DR_READ
                if ve_status:
                    rules.append((off, 0, 0xFF, 0, 0, RULE_EXACT_OFF | RULE_VE_STATUS))
            elif fn == uart_read and uart_idle and (off & 0x1F) != 0:
                rflags[off] = rflags.get(off, 0) | DR_READ | DR_UART_IDLE
                reg_off = off & 0x1F
                if reg_off == 5:
                    rules.append((off, 0, 0x00, 0x60, 0, RULE_EXACT_OFF))
                elif reg_off == 2:
                    rules.append((off, 0, 0x00, 0x01, 0, RULE_EXACT_OFF))
                elif reg_off == 0x12:
                    rules.append((off, 0, 0x00, 0x00, 0, RULE_EXACT_OFF))
            else:
                owner = getattr(fn, '__self__', None)
                t_name = type(owner).__name__
                if isinstance(owner, ReadyBits) and fn == owner._read:
                    rflags[off] = rflags.get(off, 0) | DR_READ
                    if owner not in seen_ready:
                        seen_ready.append(owner)
                elif isinstance(owner, DemodulatorLock) and fn == owner._read:
                    owner._cpp_core = self._core
                    rflags[off] = rflags.get(off, 0) | DR_READ
                    if owner not in seen_demod_lock:
                        seen_demod_lock.append(owner)
                elif t_name == 'InternalDemod' and fn == getattr(owner, '_read_status', None):
                    rflags[off] = rflags.get(off, 0) | DR_READ
                    if owner not in seen_idemod:
                        seen_idemod.append(owner)
                elif t_name == 'DmaRings' and fn == getattr(owner, '_read_done', None):
                    rflags[off] = rflags.get(off, 0) | DR_READ
                elif t_name == 'MirrorRegisters' and fn == getattr(owner, '_read', None):
                    rflags[off] = rflags.get(off, 0) | DR_READ
                    if owner not in seen_mirrors:
                        seen_mirrors.append(owner)
                elif t_name == 'DdrTraining' and fn in (getattr(owner, '_read_status', None), getattr(owner, '_read_capture', None)):
                    rflags[off] = rflags.get(off, 0) | DR_READ
                    seen_ddr_tr = True
                elif t_name == 'SmartCard' and fn == getattr(owner, '_r_reg', None) and smc_idle:
                    rflags[off] = rflags.get(off, 0) | DR_READ
                    ro = off - owner.base
                    if ro in (0x08, 0x0A, 0x14):
                        rules.append((off, 0xFF, 0x00, 0x00, 0, 0))
                    elif ro == 0x2C:
                        rules.append((off, 0x01, 0xFE, 0x00, 0, 0))
                elif t_name == 'Uart16550' and fn == getattr(owner, '_read', None) and not owner.rx_queue and not self._dev_replays:
                    ro = (off - owner.base) & 0xF
                    if ro >= 2:
                        rflags[off] = rflags.get(off, 0) | DR_READ
                        if ro == 2:
                            rules.append((off, 0, 0x00, 0x01, 0, RULE_EXACT_OFF))
                        elif ro == 5:
                            rules.append((off, 0, 0x00, 0x60, 0, RULE_EXACT_OFF))
                elif t_name == 'Demux':
                    d_idle = owner.mux is None and owner.status == 0 and not any(owner.write_ptr)
                    if fn == getattr(owner, '_r_control', None):
                        rflags[off] = rflags.get(off, 0) | DR_READ
                        rules.append((off, 0x01, 0xFE, 0x00, 0, 0))
                    elif fn == getattr(owner, '_r_ram_port', None):
                        rflags[off] = rflags.get(off, 0) | DR_READ
                        rules.append((off, 0x02, 0xFD, 0x00, 0, 0))
                    elif d_idle and fn == getattr(owner, '_r_pointers', None):
                        rflags[off] = rflags.get(off, 0) | DR_READ
                        if (off & 3) < 2:
                            rules.append((off, 0xFF, 0x00, 0x00, 0, 0))
                    elif d_idle and fn == getattr(owner, '_r_status', None):
                        rflags[off] = rflags.get(off, 0) | DR_READ
                        rules.append((off, 0xFF, 0x00, 0x00, 0, 0))
        if seen_selfcomp:
            for reg, (start, done, clear) in self._SELF_COMPLETING.items():
                rules.append((reg, start or 0, (~clear) & 0xFF, done & 0xFF, 0, 0))
        if seen_mac_rst:
            rules.append((0x2C000, 0x08, 0xF7, 0x00, 0, 0))
        for rb in seen_ready:
            for b_off, mask in rb.bits.items():
                rules.append((b_off, 0, 0xFF, mask & 0xFF, 0, 0))
        for mr in seen_mirrors:
            for target, (source, n) in mr.mirrors.items():
                for i in range(n):
                    t_i, s_i = target + i, source + i
                    rules.append((t_i, 1, s_i & 0xFF, (s_i >> 8) & 0xFF, (s_i >> 16) & 0xFF, RULE_MIRROR))
        if seen_ddr_tr:
            rules.append((0x3E08C, 0, 0, 0, 0, RULE_DDR_TRAINING))
        for dl in seen_demod_lock:
            for reg, lfn in dl.LOCKED.items():
                v0 = lfn(0) & 0xFF
                v1 = lfn(0xFF) & 0xFF
                rules.append((dl.BASE + reg, 0, (v1 ^ v0) & 0xFF, v0, 0, RULE_DEMOD | RULE_DEMOD_COUNT))
        if seen_idemod:
            from demods import S3501
            for idmd in seen_idemod:
                for reg, val in S3501.LOCK_REGS.items():
                    if reg == 0x04:
                        rules.append((idmd.base + reg, 0, 0xFF, 0x3F, 0, RULE_DEMOD | RULE_DEMOD_CLR3F))
                    elif reg == 0x68:
                        rules.append((idmd.base + reg, 0, 0xFC, 0x01, 0, RULE_DEMOD))
                    elif reg == 0x6B:
                        rules.append((idmd.base + reg, 0, 0x00, 0x68, 0, RULE_DEMOD))
                    else:
                        rules.append((idmd.base + reg, 0, 0xFF, val & 0xFF, 0, RULE_DEMOD | RULE_DEMOD_IFZERO))
        chip_id_store = self._hook_chip_id_store
        uart_write = self._hook_uart_write
        sdram_cmd = getattr(self.chip, '_sdram_command', None)
        seen_vpo = []
        seen_vpo_m36f = []
        seen_ve_st = []
        seen_ge3602 = []
        seen_osd_pal = False
        seen_sdram_cmd = []
        seen_trng = []
        for off, handlers in self._mmio_wr.items():
            if len(handlers) != 1 or off in wr_obs or not (want.get(off, 0) & DF_WRITE):
                continue
            fn = handlers[0]
            if fn == chip_id_store:
                rflags[off] = rflags.get(off, 0) | DR_WRITE | DR_WRITE_IGNORE
            elif fn == uart_write and (off & 0xF) != 0:
                rflags[off] = rflags.get(off, 0) | DR_WRITE
            elif fn == uart_write and uart_tx:
                # (opt-in: the transmit holding register's bytes go to _cpp_uart_tx in bulk)
                rflags[off] = rflags.get(off, 0) | DR_UART_TX
            elif sdram_cmd is not None and fn == sdram_cmd:
                rflags[off] = rflags.get(off, 0) | DR_WRITE | DR_VPO
                if off not in seen_sdram_cmd:
                    seen_sdram_cmd.append(off)
            else:
                owner = getattr(fn, '__self__', None)
                t_name = type(owner).__name__
                if t_name == 'VideoOutput' and fn == getattr(owner, '_write', None):
                    rflags[off] = rflags.get(off, 0) | DR_WRITE | DR_VPO
                    if owner not in seen_vpo:
                        seen_vpo.append(owner)
                elif t_name == 'VideoOutputM36F' and fn in (getattr(owner, '_write0', None), getattr(owner, '_write1', None)):
                    rflags[off] = rflags.get(off, 0) | DR_WRITE | DR_VPO
                    if owner not in seen_vpo_m36f:
                        seen_vpo_m36f.append(owner)
                elif t_name == 'VideoEngine' and fn == getattr(owner, '_write_status', None):
                    rflags[off] = rflags.get(off, 0) | DR_WRITE | DR_VPO
                    if owner not in seen_ve_st:
                        seen_ve_st.append(owner)
                elif t_name == 'GeM3602' and fn in (getattr(owner, '_write_control', None), getattr(owner, '_write_status', None)):
                    rflags[off] = rflags.get(off, 0) | DR_WRITE | DR_VPO
                    if owner not in seen_ge3602:
                        seen_ge3602.append(owner)
                elif t_name == 'Osd' and fn in (getattr(owner, '_write0', None), getattr(owner, '_write1', None)):
                    rflags[off] = rflags.get(off, 0) | DR_WRITE | DR_VPO
                    seen_osd_pal = True
                elif t_name == 'Trng' and fn == getattr(owner, '_write', None):
                    rflags[off] = rflags.get(off, 0) | DR_WRITE | DR_VPO
                    if off not in seen_trng:
                        seen_trng.append(off)
                elif t_name == 'SmartCard' and fn == getattr(owner, '_w_reg', None) and smc_idle:
                    ro = off - owner.base
                    rflags[off] = rflags.get(off, 0) | DR_WRITE | (DR_WRITE_IGNORE if ro in (0x06, 0x07) else 0)
                elif t_name == 'InternalDemod' and fn == getattr(owner, '_write', None):
                    ro = (off - owner.base) & 0xFFF
                    rflags[off] = rflags.get(off, 0) | DR_WRITE | (DR_WRITE_IGNORE if ro >= 0xA3 else 0)
                elif t_name == 'Uart16550' and fn == getattr(owner, '_write', None):
                    ro = (off - owner.base) & 0xF
                    if ro >= 4:
                        rflags[off] = rflags.get(off, 0) | DR_WRITE | (DR_WRITE_IGNORE if ro == 5 else 0)
                elif t_name == 'Demux' and fn == getattr(owner, '_w_pointers', None):
                    if owner.mux is None and owner.status == 0 and not any(owner.write_ptr):
                        rflags[off] = rflags.get(off, 0) | DR_WRITE | (DR_WRITE_IGNORE if (off & 3) < 2 else 0)
        for vo in seen_vpo:
            fb_code = (1 if (vo.field_bit & (1 << 18)) else 0) | (2 if (vo.field_bit & (1 << 19)) else 0)
            rules.append((vo.register & 0xFFFFFF, vo.line & 0xFF, fb_code, 0, 0, RULE_VPO_WRITE))
        for vm in seen_vpo_m36f:
            rules.append((0x6288, vm.line & 0xFF, 0, 0, 0, RULE_VPO_M36F_WRITE))
        for ve in seen_ve_st:
            rules.append(((ve.base & 0xFFFFFF) + 0x18, ve.line & 0xFF, 0, 0, 0, RULE_VE_STATUS_WRITE))
        for ge36 in seen_ge3602:
            rules.append((ge36.base & 0xFFFFFF, 0, 0, 0, 0, RULE_GE3602_WRITE))
        if seen_osd_pal:
            rules.append((0x41AC, 0, 0, 0, 0, RULE_OSD_PAL_WRITE))
        for sc_off in seen_sdram_cmd:
            rules.append((sc_off, 0, 0, 0, 0, RULE_SDRAM_CMD))
        for tr_off in seen_trng:
            rules.append((tr_off, 0, 0, 0, 0, RULE_TRNG_WRITE))
        if self._shared is None:
            for m in getattr(self, 'i2c_masters', ()):
                if getattr(m, '_scb_slot', -1) >= 0 and all(
                    o not in rd_obs and o not in wr_obs
                    and self._mmio_rd.get(o) == [m._read] and self._mmio_wr.get(o) == [m._write]
                    and (want.get(o, 0) & (DF_READ | DF_WRITE)) == (DF_READ | DF_WRITE)
                    for o in range(m.base, m.base + m.SIZE)
                ):
                    m._cpp_active = True
                    for o in range(m.base, m.base + m.SIZE):
                        rflags[o] = rflags.get(o, 0) | DR_SCB
                else:
                    m._cpp_active = False
        rules_key = (tuple(rules), tuple(sorted(rflags.items())))
        if rules_key != self._dev_rules_pushed:
            self._dev_rules_pushed = rules_key
            nr = len(rules)
            no = len(rflags)
            c_rules = (_MmioRule * max(1, nr))(*[_MmioRule(*r) for r in rules]) if nr else None
            r_items = sorted(rflags.items())
            c_offs = (ctypes.c_uint32 * max(1, no))(*[k for k, _ in r_items]) if no else None
            c_rfl = (ctypes.c_uint8 * max(1, no))(*[v for _, v in r_items]) if no else None
            L.ali_set_mmio_rules(h, c_rules, nr, c_offs, c_rfl, no)

    def _ge_execute(self, command):
        """Fallback GE execution when a command list or IO primitive in Core::ge_store
        returns to Python (or when an MMIO observer disables DF_GE)."""
        from simulator import _get_np
        np = _get_np()
        if np is None:
            return
        if self.ge is None:
            import ge_m36f
            ram = np.frombuffer(self.ram_buffer, dtype=np.uint8, count=self.ram_size)
            self.ge = ge_m36f.GeM36F(ram, log=self.log)
        L, h = cpp_core.lib(), self._core.handle
        c_regs = (ctypes.c_uint32 * 64)()
        L.ali_ge_regs(h, 0, c_regs)
        self.ge.regs[:] = [int(c_regs[i]) for i in range(64)]
        self.ge.primitives = int(self._core.get(cpp_core.F_GE_PRIMS))
        resume = self._core.get(cpp_core.F_GE_RESUME)
        self._core.set(cpp_core.F_GE_RESUME, 0xFFFFFFFFFFFFFFFF)
        regs_arr = np.frombuffer(self._mmio_view[0xA000:0xA100], dtype='<u4')
        if command == 1:
            self.ge.run_io(regs_arr if (self.ge.fast_paths and self.ge.trace is None) else regs_arr.tolist())
        else:
            o = 0x10 if command == 2 else 0x18
            start, end = int(regs_arr[o >> 2]) & 0x1FFFFFFF, int(regs_arr[(o >> 2) + 1]) & 0x1FFFFFFF
            if (start != 0 or end != 0) and start <= end < start + 0x400000 and end + 4 <= self.ram_size:
                words_view = self.ge.ram[start:end + 4].view('<u4')
                if resume != 0xFFFFFFFFFFFFFFFF and resume < len(words_view):
                    words_view = words_view[resume:]
                if self.ge.fast_paths and self.ge.trace is None:
                    self.ge.run_list(words_view, regs_arr)
                else:
                    self.ge.run_list(words_view.tolist(), regs_arr.tolist())
        for i in range(64):
            c_regs[i] = self.ge.regs[i] & 0xFFFFFFFF
        L.ali_ge_regs(h, 1, c_regs)
        self._core.set(cpp_core.F_GE_PRIMS, self.ge.primitives)

    def _cpp_dev(self, user, write, offset, size, value):
        """A device window access that needs Python (the core's DevCb); the GPIO
        events the core logged before it first."""
        try:
            n = self._gpio_count[0]
            if n:
                data = self._gpio_pairs[:2 * n]
                self._gpio_count[0] = 0
                self._gpio_events(data, n)
            if write:
                self._mmio_write(self.mu, offset, size, value, None)
                if self.signal_frequencies is not None:
                    self._cpp_demod_sync()
                return 0
            res = self._mmio_read(self.mu, offset, size, None) & 0xFFFFFFFFFFFFFFFF
            if self._gpio_di_busy_pushed:
                self._cpp_gpio_busy_sync()
            return res
        except BaseException as e:
            self.mu._catch(e)
            return 0

    def _cpp_uart_tx(self, user, data, count):
        """UART transmit bytes the core logged (uart_tx_native: DR_UART_TX), in
        order, handed over like the GPIO log: before another call into Python and
        when a run returns.  Each goes to the UART handler as _hook_uart_write
        would have passed it."""
        try:
            if self.uart_bulk_callback is not None:
                self.uart_bulk_callback(ctypes.string_at(data, count))
                return
            log = self._uart_log
            for value in ctypes.string_at(data, count):
                log(value)
        except BaseException as e:
            self.mu._catch(e)

    def _cpp_gpio(self, user, pairs, count):
        """GPIO stores the core logged (DF_GPIO_*), handed over before another
        call into Python than a device access (_cpp_dev empties the log itself)
        and when a run returns."""
        try:
            self._gpio_events(pairs[:2 * count], count)
        except BaseException as e:
            self.mu._catch(e)

    def _gpio_events(self, data, count):
        """The logged pin levels after each GPIO store, to the GPIO handler and
        the board's GPIO devices, in order (as _hook_gpio_write passes them) --
        but the bit-banged I2C bus the core runs itself (_cpp_gpio_sync)."""
        cb, devices = self.gpio_callback, self.gpio_devices
        bus = self._gi2c_bus
        tm_dec = self._tm1650_dec
        tm28_dec = self._tm1628_dec
        hc_dec = self._hc164_dec
        lt_dec = self._lemontree_dec
        native_decs = (tm_dec, tm28_dec, hc_dec, lt_dec)
        if cb is not None and getattr(cb, '__self__', None) in native_decs and getattr(cb, '__self__', None) is not None:
            cb = None
        if (bus is not None or any(d is not None for d in native_decs)) and devices:
            devices = [d for d in devices if d is not bus and d not in native_decs]
        if not cb:
            ndev = len(devices)
            if ndev == 0:
                return
            if ndev == 1:
                on_write = devices[0].on_gpio_write
                for i in range(0, 2 * count, 2):
                    on_write(0xB8000000 | data[i], 4, data[i + 1])
                self._cpp_gpio_busy_sync()
                return
        elif not devices:
            for i in range(0, 2 * count, 2):
                cb(0xB8000000 | data[i], 4, data[i + 1])
            self._cpp_gpio_busy_sync()
            return
        for i in range(0, 2 * count, 2):
            address, levels = 0xB8000000 | data[i], data[i + 1]
            if cb:
                cb(address, 4, levels)
            for device in devices:
                device.on_gpio_write(address, 4, levels)
        self._cpp_gpio_busy_sync()

    def _cpp_event(self, user, kind, a, b):
        try:
            if kind == EVT_FLASH_READ:
                self._spi_flash_read(self.mu, a, b)
            elif kind == EVT_CODE_CHUNK:
                self._rescan_cp0_sites([(0x80000000 | a, b)])
            elif kind == EVT_UART_IRQ:
                self.log(f"[UART IRQ] Delivering interrupt #{self._uart_irq_retries} -> {hex(b)} "
                         f"(from {hex(a & ~1)}, icount={self.instruction_count})")
            elif kind == EVT_UART_ERET:
                if len(self._uart_rx_queue) > 0:
                    self._pending_uart_irq = True
                    self._uart_irq_delivered = False
                    self._uart_irq_arm_after = max(self._uart_irq_arm_after, self.instruction_count + 100)
        except BaseException as e:
            self.mu._catch(e)

    def _hook_flash_write_prot(self, uc, access, address, size, value, user_data):
        """A store to the flash window (the Python SPI / parallel flash models): the
        model carries it out, and nothing lands -- the flash shows what the model
        says at once (on Unicorn the store landed and was put back later)."""
        r = super()._hook_flash_write_prot(uc, access, address, size, value, user_data)
        if r is True and any(w <= address < w + 0x01000000 for w in self._flash_windows):
            self._rom_restore()
            return 2
        return r

    # (no replayed device accesses on this core: a stop ends an instruction cleanly)
    def _device_access(self, uc, hooked=False):
        self._dev_last = None

    def _dev_note(self, uc, kind, address, data, exact=None):
        pass

    def _clear_branch_flags(self):
        pass

    def _irq_soon(self):
        pass                            # (the core sees a raised line at the next instruction)

    # ---- the flash window's command mode ----
    def _spi_can_inline_status(self):
        # Native SPI already handles status reads without Python.  Its fallback
        # must use the flash callback: replacing ROM bytes with a status value
        # would leave those bytes behind when the native controller takes over.
        return False

    def _spi_write_ins(self, uc, cmd):
        super()._spi_write_ins(uc, cmd)
        # The shared fast paths do not install Unicorn hooks.  Keep this core's
        # separate flash callback flag in sync even when one returns early.
        self._update_flash_read_hooks()

    def _update_flash_read_hooks(self):
        native = '_core' in self.__dict__ and cpp_core.lib().ali_spi_get(self._core.handle, S_ON)
        wanted = self._flash_hooks_wanted() and not native
        if wanted:
            self._spi_cmd_vt = self._vtime()
        if wanted != self._flash_cmd_on:
            self._flash_cmd_on = wanted
            self.flash_hook_changes += 1
            wins = (ctypes.c_uint32 * len(self._flash_windows))(*self._flash_windows)
            cpp_core.lib().ali_set_flash_cmd(self._core.handle, int(wanted), wins, len(self._flash_windows))
        self._flash_hooks_pending = False

    def setSPIDump(self, enabled, flash_reads=False):
        super().setSPIDump(enabled, flash_reads)
        if '_core' in self.__dict__:
            self._cpp_spi_sync()

    def _apply_flash_hooks(self, force=False):
        self._update_flash_read_hooks()

    def _sync_flash_windows(self):
        if '_core' in self.__dict__:
            wins = (ctypes.c_uint32 * len(self._flash_windows))(*self._flash_windows)
            cpp_core.lib().ali_set_flash_cmd(self._core.handle, int(self._flash_cmd_on), wins, len(self._flash_windows))

    def _on_ram_size_changed(self):
        if '_core' in self.__dict__:
            L = cpp_core.lib()
            L.ali_set_chunks(self._core.handle, 20, min(self.ram_size, 0x10000000) >> 20)
            L.ali_ge_config(self._core.handle, ctypes.addressof(self.ram_buffer), self.ram_size)

    def _update_short_block_hook(self):
        pass

    # ---- the interrupt controller ----
    @property
    def _ic_lines(self):
        if '_core' not in self.__dict__:
            return self.__dict__.get('_ic_lines_v', 0)
        hi = self._core.get(F_IC_LINES_HI)
        self.__dict__['_ic_lines_hi_pushed'] = hi
        return (hi << 64) | self._core.get(F_IC_LINES)

    @_ic_lines.setter
    def _ic_lines(self, value):
        self.__dict__['_ic_lines_v'] = value
        self._core.set(F_IC_LINES, value & 0xFFFFFFFFFFFFFFFF)
        hi = (value >> 64) & 0xFFFFFFFFFFFFFFFF
        if hi != self.__dict__.get('_ic_lines_hi_pushed', -1):
            self.__dict__['_ic_lines_hi_pushed'] = hi
            self._core.set(F_IC_LINES_HI, hi)

    def set_ic_layout(self, status, enable):
        super().set_ic_layout(status, enable)
        cpp_core.lib().ali_set_ic(self._core.handle, status, enable, self.ic_base)

    @property
    def _IC_GE(self):
        return int(self._core.get(F_GE_IC_LINE)) if '_core' in self.__dict__ else 4

    @_IC_GE.setter
    def _IC_GE(self, value):
        if '_core' in self.__dict__:
            self._core.set(F_GE_IC_LINE, int(value))

    @property
    def doorbell_in(self):
        return self._doorbell

    @doorbell_in.setter
    def doorbell_in(self, value):
        self._doorbell = value
        if value is None:
            cpp_core.lib().ali_set_doorbell(self._core.handle, -1, 0)
        else:
            cpp_core.lib().ali_set_doorbell(self._core.handle, value[0], value[1])

    def _ic_ip3(self):
        return bool(self._core.get(F_IC_IP3))

    # ------------------------------------------------------------------
    # CPU state, time
    # ------------------------------------------------------------------
    def is_mips16_mode(self, pc=None):
        return bool(self._core.get(F_M16))

    def get_hflags(self):
        return (0x400 if self._core.get(F_M16) else 0) | (0x800 if self._core.get(F_DS_ACTIVE) else 0)

    @property
    def isa_mode(self):
        return ISAMode.MIPS16 if self.is_mips16_mode() else ISAMode.MIPS32

    @isa_mode.setter
    def isa_mode(self, value):
        self._isa_mode_fallback = value
        pc = self.mu.reg_read(UC_MIPS_REG_PC) & ~1
        self.mu.reg_write(UC_MIPS_REG_PC, pc | (1 if value == ISAMode.MIPS16 else 0))

    def _start_pc(self, pc):
        same = (pc & ~1) == self.mu.reg_read(UC_MIPS_REG_PC)
        m16 = self.is_mips16_mode() if same else bool(pc & 1) or self.is_mips16_addr(pc)
        return (pc & ~1) | (1 if m16 else 0)

    def _at_safe_point(self):
        return not self._core.get(F_DS_ACTIVE)

    def _vtime(self):
        """Emulation time in seconds: the core's instruction count at cpp_ips."""
        return self._core.get(F_ICOUNT) / self.cpp_ips

    def _setup_clock(self):
        pass

    @property
    def _vt_accum(self):
        """(The Unicorn engine's emulation time of finished slices: here the clock.)"""
        return self._vtime()

    @_vt_accum.setter
    def _vt_accum(self, value):
        if '_core' in self.__dict__ and self.__dict__.get('_hflags_off') is not None:
            self._core.set(F_ICOUNT, max(0, int(round(value * self.cpp_ips))))

    @property
    def idle_skipped(self):
        """Emulation time the core skipped in idle loops (seconds)."""
        return self._core.get(F_IDLE_SKIPPED) / self.cpp_ips

    @idle_skipped.setter
    def idle_skipped(self, value):
        self._core.set(F_IDLE_SKIPPED, int(round(value * self.cpp_ips)))

    @property
    def cpp_access_cost(self):
        """Instructions of emulated time a device access handled in Python costs."""
        return self._core.get(cpp_core.F_HOST_ACCESS_COST)

    @cpp_access_cost.setter
    def cpp_access_cost(self, value):
        self._core.set(cpp_core.F_HOST_ACCESS_COST, int(value))

    @property
    def count_hz(self):
        return self._count_hz_v

    @count_hz.setter
    def count_hz(self, value):
        self._count_hz_v = value
        if '_core' in self.__dict__ and self.__dict__.get('_hflags_off') is not None:
            self._apply_count_ratio()

    def _apply_count_ratio(self):
        """Count per instruction: 2 in exact mode (the hardware's half clock), else
        count_hz per emulated second."""
        if self._want_full_hook():
            cpp_core.lib().ali_set_count_ratio(self._core.handle, 2, 1)
        else:
            cpp_core.lib().ali_set_count_ratio(self._core.handle, int(self._count_hz_v), int(self.cpp_ips))

    @property
    def cp0_count(self):
        return self._core.get(F_COUNT)

    @cp0_count.setter
    def cp0_count(self, value):
        self._core.set(F_COUNT_RAW_WRITE, value)

    def _cp0_count_now(self):
        return self._core.get(F_COUNT)

    def _rebase_count(self):
        pass

    @property
    def _count_observed(self):
        return self._core.get(F_COUNT_OBSERVED) if self._core.get(F_COUNT_OBSERVED_VALID) else None

    @_count_observed.setter
    def _count_observed(self, value):
        self._core.set(F_COUNT_OBSERVED_VALID, value is not None)
        if value is not None:
            self._core.set(F_COUNT_OBSERVED, value)

    @property
    def timer_enabled(self):
        return bool(self._core.get(F_TIMER_ENABLED))

    @timer_enabled.setter
    def timer_enabled(self, on):
        self._core.set(F_TIMER_ENABLED, bool(on))

    def _timer_update(self, now=None):
        cpp_core.lib().ali_timer_update(self._core.handle)

    def _write_compare(self, val):
        self._core.set(F_COMPARE_WRITE, val)

    def _cause_value(self):
        return self._core.get(F_CAUSE_VALUE)

    def _irq_deliverable(self):
        cpp_core.lib().ali_timer_update(self._core.handle)     # (a Compare passed by a time step latches first)
        return bool(self._core.get(F_IRQ_DELIVERABLE))

    def _enter_interrupt(self, uc, epc):
        vec = cpp_core.lib().ali_enter_interrupt(self._core.handle, epc & 0xFFFFFFFF)
        return vec

    def _cp0_read(self, rd, sel):
        return cpp_core.lib().ali_cp0_read(self._core.handle, rd, sel)

    def _cp0_write(self, uc, rd, sel, val):
        cpp_core.lib().ali_cp0_write(self._core.handle, rd, sel, val & 0xFFFFFFFF)
        return False

    def _reschedule_slice(self):
        pass

    def _irq_gap_left(self, now=None):
        return 0.0

    def _timer_wait_us(self, count=None):
        """Microseconds of emulation time until Count reaches Compare (None: no tick
        due; 0: one is pending and deliverable)."""
        d = cpp_core.lib().ali_timer_wait(self._core.handle)      # (one call: the core checks all of it)
        if d < 0:
            return None if d == -1 else 0.0
        return d * 1e6 / self._count_hz_v

    def _get_stopper(self):
        return None

    # the UART receive interrupt's arming point, in instruction_count units for Python
    @property
    def _uart_irq_arm_after(self):
        return self._uart_arm_units

    @_uart_irq_arm_after.setter
    def _uart_irq_arm_after(self, value):
        self._uart_arm_units = value
        if self.__dict__.get('_hflags_off') is None:
            return                      # (still in __init__)
        ahead = max(0, value - self.instruction_count)
        exact = self._want_full_hook() or self._timeout_slices == 0
        per_unit = 1.0 if exact else self.cpp_ips / self._insn_rate
        self._core.set(F_UART_AT, self._core.get(F_ICOUNT) + int(ahead * per_unit))

    def _services_due(self):
        """The earliest due() of the slice services that have one, or None."""
        due = None
        for service in self.slice_services:
            fn = getattr(getattr(service, '__self__', None), 'due', None)
            t = fn() if fn is not None else None
            if t is not None and (due is None or t < due):
                due = t
        return due

    def _advance_time(self, seconds):
        """Between slices: the emulation time moves on (the core's clock), and the
        instruction count with it at _insn_rate (to the budget at most)."""
        ticks = int(round(seconds * self.cpp_ips))
        if seconds > 0 and ticks < 1:
            ticks = 1                   # (the clock is whole instructions: a shorter step would never end)
        self._core.set(F_ICOUNT, self._core.get(F_ICOUNT) + ticks)
        counted = round(seconds * self._insn_rate)
        budget = self._budget()
        if budget is not None:
            counted = min(counted, budget)
        self.instruction_count += counted

    def _delay_jump(self, wait):
        self._core.set(F_ICOUNT, self._core.get(F_ICOUNT) + int(round(wait * self.cpp_ips)))
        self.delay_skipped += wait

    # The RTOS's delay() shortcut (simulator.delay_hle): the Python hooks, with the
    # time a wait may skip ending at the slice's end or the next timer interrupt,
    # whichever comes first -- the core then takes the interrupt itself, inside the
    # wait as on the hardware (no slice stop needed).
    @property
    def _slice_cap_end(self):
        return self.__dict__.get('_cpp_slice_end')

    @_slice_cap_end.setter
    def _slice_cap_end(self, value):
        pass

    @property
    def _slice_armed_end(self):
        end = self.__dict__.get('_cpp_slice_end')
        if end is None:
            return None
        w = self._timer_wait_us()
        if w is not None:
            end = min(end, self._vtime() + w / 1e6)
        return end

    @_slice_armed_end.setter
    def _slice_armed_end(self, value):
        pass

    def _hook_delay_loop(self, uc, address, size, user_data):
        entry = self._delay_loops.get(address)
        routine = self._delay_routine(entry) if size == 4 and entry is not None else None
        if routine is None or self._slice_cap_end is None:
            return
        build = self._DELAYS[routine[3]]
        ticks, start = self._reg_read(self.gpr_map[build["ticks"]]), self._reg_read(self.gpr_map[build["start"]])
        if build["past"]:
            if ticks == 0xFFFFFFFF:
                return
            ticks += 1
        waited = (self._cp0_count_now() - start) & 0xFFFFFFFF
        if waited >= ticks:
            return
        wait, room = (ticks - waited) / self.count_hz, self._slice_armed_end - self._vtime()
        self.delay_jumps += 1
        self._delay_jump(min(wait, max(0.0, room)))

    # ------------------------------------------------------------------
    # Hooks: breakpoints, the exact mode's per-instruction bookkeeping,
    # LzmaDecode() found in new code
    # ------------------------------------------------------------------
    def _cpp_sync(self):
        """Before the core runs: the device window flags, the native breakpoints,
        the exact mode, the flash command mode."""
        self._cpp_spi_sync()
        self._cpp_dev_flags()
        self._cpp_demod_sync()
        if self.breakpoints or self.stop_instr is not None or self._bp_pushed:
            wanted = set(self.breakpoints)
            if self.stop_instr is not None:
                wanted.add(self.stop_instr)
            if wanted != self._bp_pushed:
                self._bp_pushed = set(wanted)
                arr = (ctypes.c_uint32 * max(1, len(wanted)))(*sorted(a & 0xFFFFFFFF for a in wanted))
                cpp_core.lib().ali_set_breakpoints(self._core.handle, arr, len(wanted))
        full = self._want_full_hook()
        if full != (self._exact_hook is not None):
            if full:
                self._exact_hook = self._core.hook_add(UC_HOOK_CODE, self._cpp_hook_code)
                self._code_hook_h = self._exact_hook
                self._core.set(F_EXACT, 1)
                self._apply_count_ratio()
            else:
                self._core.hook_del(self._exact_hook)
                self._exact_hook = None
                self._code_hook_h = None
                self._core.set(F_EXACT, 0)
                self._apply_count_ratio()
        if self._flash_hooks_pending:
            self._update_flash_read_hooks()
        self._cpp_gpio_sync()

    def _cpp_demod_sync(self):
        demod = getattr(self.chip, 'nim', None) or getattr(self.chip, 'demod', None)
        locked = bool(demod is not None and getattr(demod, 'signal', False) and self.tuned_to_signal())
        if locked != self._demod_locked_pushed:
            self._demod_locked_pushed = locked
            self._core.set(F_DEMOD_LOCKED, 1 if locked else 0)

    def _cpp_gpio_sync(self):
        """The board's bit-banged I2C bus (gpio_i2c.GpioI2cBus) and TM1650 display/key
        decoder (tm1650_decoder.TM1650Decoder) run in the core (Core::gi2c_* / tm1650_*):
        it follows every GPIO store there and calls the bus's native_slave() / native_tx()
        per transaction, not _gpio_events per edge (ALISIM_CPP_GPIO_I2C=0: in Python).
        The GPIO log then carries only the stores that change a pin the other
        decoders watch, when every one of them says which (gpio_watch())."""
        devices = getattr(self, 'gpio_devices', None) or []
        callback = getattr(self, 'gpio_callback', None)
        cb_owner = getattr(callback, '__self__', None) if callback else None
        use_native_gpio = os.environ.get("ALISIM_CPP_GPIO_I2C", "1") != "0"
        sync_key = (
            use_native_gpio,
            id(callback),
            tuple(id(d) for d in devices),
            getattr(cb_owner, 'dump_enabled', None),
            getattr(cb_owner, 'on_transaction', None) is not None,
            getattr(cb_owner, 'on_frame', None) is not None,
            tuple((getattr(d, 'dump_enabled', None), getattr(d, 'on_transaction', None) is not None,
                   getattr(d, 'on_frame', None) is not None) for d in devices),
        )
        if sync_key == self._gpio_sync_key:
            if self._gpio_di_owners:
                self._cpp_gpio_busy_sync()
            return
        self._gpio_sync_key = sync_key
        from gpio_i2c import GpioI2cBus
        from tm1650_decoder import TM1650Decoder
        from tm1628_decoder import TM1628Decoder
        from hc164_decoder import HC164Decoder
        from lemontree_decoder import LemontreeDecoder
        L, h = cpp_core.lib(), self._core.handle
        bus = None
        tm_dec = None
        tm28_dec = None
        hc_dec = None
        lt_dec = None
        if use_native_gpio:
            bus = next((d for d in devices if isinstance(d, GpioI2cBus)), None)
            if isinstance(cb_owner, TM1650Decoder) and not cb_owner.dump_enabled:
                tm_dec = cb_owner
            else:
                tm_dec = next((d for d in devices if isinstance(d, TM1650Decoder) and not d.dump_enabled), None)
            if isinstance(cb_owner, TM1628Decoder) and not cb_owner.dump_enabled:
                tm28_dec = cb_owner
            else:
                tm28_dec = next((d for d in devices if isinstance(d, TM1628Decoder) and not d.dump_enabled), None)
            if isinstance(cb_owner, HC164Decoder) and not cb_owner.dump_enabled:
                hc_dec = cb_owner
            else:
                hc_dec = next((d for d in devices if isinstance(d, HC164Decoder) and not d.dump_enabled), None)
            if isinstance(cb_owner, LemontreeDecoder) and not cb_owner.dump_enabled:
                lt_dec = cb_owner
            else:
                lt_dec = next((d for d in devices if isinstance(d, LemontreeDecoder) and not d.dump_enabled), None)
        if bus is not self._gi2c_bus:
            if self._gi2c_bus is not None:
                self._gi2c_bus.native = None
            if bus is None:
                L.ali_gpio_i2c_config(h, 0, 0, 0, 0, 0, None, None)
            else:
                if self._gi2c_cb is None:
                    self._gi2c_cb = cpp_core._I2C_CB(self._cpp_i2c)
                L.ali_gpio_i2c_config(h, 1, bus.scl_offset, bus.scl_bit, bus.sda_offset, bus.sda_bit,
                                      ctypes.cast(self._gi2c_cb, ctypes.c_void_p), None)
                get = L.ali_gpio_i2c_get
                bus.native = lambda field, _get=get, _h=h: _get(_h, field)
            self._gi2c_bus = bus
        if tm_dec is not self._tm1650_dec:
            if self._tm1650_dec is not None:
                self._tm1650_dec.native = None
                self._tm1650_dec.native_press = None
            if tm_dec is None:
                L.ali_tm1650_config(h, 0, 0, 0, 0, 0, 0, None, None)
            else:
                if self._tm1650_cb is None:
                    self._tm1650_cb = cpp_core._I2C_CB(self._cpp_tm1650)
                L.ali_tm1650_config(
                    h, 1, tm_dec.scl_offset, tm_dec.scl_bit, tm_dec.sda_offset, tm_dec.sda_bit,
                    1 if tm_dec.on_transaction is not None else 0,
                    ctypes.cast(self._tm1650_cb, ctypes.c_void_p), None
                )
                get_tm = L.ali_tm1650_get
                set_key = L.ali_tm1650_set_key
                tm_dec.native = lambda field, _get=get_tm, _h=h: _get(_h, field)
                tm_dec.native_press = lambda kb, hold, _sk=set_key, _h=h: _sk(_h, kb, hold)
                if tm_dec._key_byte or tm_dec._press_reads_left_v:
                    set_key(h, tm_dec._key_byte, tm_dec._press_reads_left_v)
            self._tm1650_dec = tm_dec
        if tm28_dec is not self._tm1628_dec:
            if self._tm1628_dec is not None:
                self._tm1628_dec.native = None
                self._tm1628_dec.native_press = None
            if tm28_dec is None:
                L.ali_tm1628_config(h, 0, 0, 0, 0, 0, 0, 0, 0, None, None)
            else:
                if self._tm1628_cb is None:
                    self._tm1628_cb = cpp_core._I2C_CB(self._cpp_tm1628)
                L.ali_tm1628_config(
                    h, 1, tm28_dec.clk_offset, tm28_dec.clk_bit, tm28_dec.dio_offset, tm28_dec.dio_bit,
                    tm28_dec.stb_offset, tm28_dec.stb_bit, 1 if tm28_dec.on_frame is not None else 0,
                    ctypes.cast(self._tm1628_cb, ctypes.c_void_p), None
                )
                get_tm28 = L.ali_tm1628_get
                set_key28 = L.ali_tm1628_set_key
                tm28_dec.native = lambda field, _get=get_tm28, _h=h: _get(_h, field)
                def _press28(kb, hold, _sk=set_key28, _h=h):
                    arr = (ctypes.c_uint8 * 5)(*(kb[:5]))
                    _sk(_h, arr, hold)
                tm28_dec.native_press = _press28
                if any(tm28_dec.key_bytes) or tm28_dec._press_reads_left:
                    _press28(tm28_dec.key_bytes, tm28_dec._press_reads_left)
            self._tm1628_dec = tm28_dec
        if hc_dec is not self._hc164_dec:
            if self._hc164_dec is not None:
                self._hc164_dec.native = None
            if hc_dec is None:
                L.ali_hc164_config(h, 0, 0, 0, 0, 0, None, None, 0, 0, 0, None, None)
            else:
                if self._hc164_cb is None:
                    self._hc164_cb = cpp_core._I2C_CB(self._cpp_hc164)
                ndig = len(hc_dec.digit_pins)
                doffs = (ctypes.c_uint32 * max(1, ndig))(*[off for off, _ in hc_dec.digit_pins])
                dbits = (ctypes.c_uint32 * max(1, ndig))(*[bit for _, bit in hc_dec.digit_pins])
                L.ali_hc164_config(
                    h, 1, hc_dec.clk_offset, hc_dec.clk_bit, hc_dec.data_offset, hc_dec.data_bit,
                    doffs, dbits, ndig, int(hc_dec.active_low_segments), int(hc_dec.active_low_digits),
                    ctypes.cast(self._hc164_cb, ctypes.c_void_p), None
                )
                get_hc = L.ali_hc164_get
                hc_dec.native = lambda field, _get=get_hc, _h=h: _get(_h, field)
            self._hc164_dec = hc_dec
        if lt_dec is not self._lemontree_dec:
            if self._lemontree_dec is not None:
                self._lemontree_dec.native = None
                self._lemontree_dec.native_press = None
            if lt_dec is None:
                L.ali_lemontree_config(h, 0, 0, 0, 0, 0, 0, None, None)
            else:
                if self._lemontree_cb is None:
                    self._lemontree_cb = cpp_core._I2C_CB(self._cpp_lemontree)
                L.ali_lemontree_config(
                    h, 1, lt_dec.scl_offset, lt_dec.scl_bit, lt_dec.sda_offset, lt_dec.sda_bit,
                    0, ctypes.cast(self._lemontree_cb, ctypes.c_void_p), None
                )
                get_lt = L.ali_lemontree_get
                set_key_lt = L.ali_lemontree_set_key
                lt_dec.native = lambda field, _get=get_lt, _h=h: _get(_h, field)
                lt_dec.native_press = lambda kb, hold, _sk=set_key_lt, _h=h: _sk(_h, kb, hold)
                if lt_dec.key_byte or lt_dec._press_reads_left:
                    set_key_lt(h, lt_dec.key_byte, lt_dec._press_reads_left)
            self._lemontree_dec = lt_dec
        native_decs = tuple(d for d in (tm_dec, tm28_dec, hc_dec, lt_dec) if d is not None)
        watch = {}
        owners = [d for d in devices if d is not bus and d not in native_decs]
        if callback and (cb_owner is None or cb_owner not in native_decs):
            owners.append(cb_owner)   # (a plain function: none)
        for owner in owners:
            fn = getattr(owner, 'gpio_watch', None)
            pins = fn() if fn is not None else None
            if pins is None:
                watch = None
                break
            for off, mask in pins.items():
                watch[off] = watch.get(off, 0) | mask
        key = None if watch is None else tuple(sorted(watch.items()))
        if key != self._gpio_watch_pushed:
            self._gpio_watch_pushed = key
            if key is None:
                L.ali_gpio_watch(h, 0, None, None, 0)
            else:
                n = len(key)
                offs = (ctypes.c_uint32 * max(1, n))(*[k for k, _ in key])
                masks = (ctypes.c_uint32 * max(1, n))(*[m & 0xFFFFFFFF for _, m in key])
                L.ali_gpio_watch(h, 1, offs, masks, n)
        di_owners = [o for o in owners if o is not None and hasattr(o, 'di_override')]
        if callback and cb_owner is None:
            for cell in getattr(callback, '__closure__', None) or ():
                try:
                    val = cell.cell_contents
                except ValueError:
                    continue
                if hasattr(val, 'di_override') and val not in di_owners and val not in native_decs:
                    di_owners.append(val)
            gdict = getattr(callback, '__globals__', None)
            code = getattr(callback, '__code__', None)
            if isinstance(gdict, dict) and code is not None:
                for name in getattr(code, 'co_names', ()):
                    val = gdict.get(name)
                    if val is not None and hasattr(val, 'di_override') and val not in di_owners and val not in native_decs:
                        di_owners.append(val)
        self._gpio_di_owners = tuple(di_owners)
        di_high = {}
        all_di_owners = list(di_owners)
        if tm_dec is not None:
            all_di_owners.append(tm_dec)
        if lt_dec is not None:
            all_di_owners.append(lt_dec)
        for o in all_di_owners:
            t = type(o).__name__
            if t == 'TM1650Decoder' or t == 'LemontreeDecoder':
                if o.scl_offset is not None:
                    di_high[o.scl_offset] = di_high.get(o.scl_offset, 0) | (1 << o.scl_bit)
                if o.sda_offset is not None:
                    di_high[o.sda_offset] = di_high.get(o.sda_offset, 0) | (1 << o.sda_bit)
            elif t == 'GpioKeys':
                for di_off, pins in o._bank_pins.items():
                    do_off = di_off + 4
                    for _pin, mask in pins:
                        di_high[do_off] = di_high.get(do_off, 0) | mask
        di_key = tuple(sorted(di_high.items()))
        if di_key != self._gpio_di_high_pushed:
            self._gpio_di_high_pushed = di_key
            n = len(di_key)
            offs = (ctypes.c_uint32 * max(1, n))(*[k for k, _ in di_key])
            masks = (ctypes.c_uint32 * max(1, n))(*[m & 0xFFFFFFFF for _, m in di_key])
            L.ali_gpio_di_config(h, offs, masks, n)
        self._cpp_gpio_busy_sync()

    def _cpp_gpio_busy_sync(self):
        busy = False
        for d in self._gpio_di_owners:
            t = type(d).__name__
            if t == 'TM1650Decoder':
                if d.state != 'IDLE':
                    busy = True
                    break
            elif t == 'LemontreeDecoder':
                if d.state not in ('IDLE', 'IGNORE'):
                    busy = True
                    break
            elif t == 'TM1628Decoder':
                if d._key_read and d.frame is not None:
                    busy = True
                    break
            elif t == 'GpioKeys':
                if any(v > 0 for v in d._held.values()):
                    busy = True
                    break
            elif t != 'HC164Decoder':
                busy = True
                break
        if busy != self._gpio_di_busy_pushed:
            self._gpio_di_busy_pushed = busy
            self._core.set(cpp_core.F_GPIO_DI_BUSY, 1 if busy else 0)

    def _cpp_i2c(self, user, kind, arg, data, n):
        """The core's bit-banged I2C bus at an address, a write transaction's
        end, a read byte (gpio_i2c.GpioI2cBus.native_slave)."""
        try:
            bus = self._gi2c_bus
            if bus is None:
                return -1 if kind == 3 else 0
            res = int(bus.native_slave(kind, arg, ctypes.string_at(data, n) if n else b""))
            if kind == 2 and self.signal_frequencies is not None:
                self._cpp_demod_sync()
            return res
        except BaseException as e:
            self.mu._catch(e)
            return 0

    def _cpp_tm1650(self, user, kind, arg, data, n):
        """The core's TM1650 decoder at a completed 2-byte transaction."""
        try:
            dec = self._tm1650_dec
            if dec is not None:
                dec.native_tx((arg >> 8) & 0xFF, arg & 0xFF)
            return 0
        except BaseException as e:
            self.mu._catch(e)
            return 0

    def _cpp_tm1628(self, user, kind, arg, data, n):
        """The core's TM1628 decoder at a completed frame."""
        try:
            dec = self._tm1628_dec
            if dec is not None and n:
                dec.native_frame(list(ctypes.string_at(data, n)))
            return 0
        except BaseException as e:
            self.mu._catch(e)
            return 0

    def _cpp_hc164(self, user, kind, arg, data, n):
        """The core's HC164 decoder at a digit update."""
        try:
            dec = self._hc164_dec
            if dec is not None and n:
                dec.native_update(list(ctypes.string_at(data, n)))
            return 0
        except BaseException as e:
            self.mu._catch(e)
            return 0

    def _cpp_lemontree(self, user, kind, arg, data, n):
        """The core's Lemontree decoder at a display update frame."""
        try:
            dec = self._lemontree_dec
            if dec is not None and n:
                dec.native_frame(int(arg), ctypes.string_at(data, n))
            return 0
        except BaseException as e:
            self.mu._catch(e)
            return 0

    def _cpp_after_start(self, executed):
        if self._rom_dirty:
            self._rom_restore()

    def _sync_hooks(self):
        self._cpp_sync()

    def _sync_hooks_if_ready(self):
        if '_core' in self.__dict__ and self.mu is not None:
            self._cpp_sync()

    def loadFile(self, filename, chip=None):
        if self.__dict__.get('_rom_image_ref') is not None:
            cpp_core.lib().ali_spi_config(self._core.handle, 0, ctypes.addressof(self.rom_buffer), None,
                                          self.rom_size, 0xEF4016)
            self._rom_image_ref = None
            self._spi_key = None
        super().loadFile(filename, chip=chip)
        self._gpio_di_high_pushed = None
        self._gpio_sync_key = None
        self._cpp_spi_sync()
        self._cpp_gpio_sync()

    def _rescan_all(self):
        """A new image: LzmaDecode() in the flash, every RAM chunk's first execution
        reported again."""
        self._rom_sites_dirty = True
        self._rescan_cp0_sites(None)
        cpp_core.lib().ali_set_chunks(self._core.handle, 20, min(self.ram_size, 0x10000000) >> 20)

    def _cpp_scan_code(self, data, base, views, ptr=None, want_lzma=True, want_delay=True, want_poll=True):
        """Scan `data` in a single C++ pass for LzmaDecode() (kind 1), delay()
        (kind 2), and mailbox poll loops (kind 3), and verify only candidate slices."""
        n = len(data)
        if n < 20:
            return
        mask = ((1 if (want_lzma and self.lzma_hle) else 0) |
                (2 if (want_delay and self.delay_hle) else 0) |
                (4 if (want_poll and self.poll_skip) else 0))
        if not mask:
            return
        c_buf = None
        if ptr is None:
            if isinstance(data, bytearray):
                c_buf = (ctypes.c_char * n).from_buffer(data)
                ptr = ctypes.addressof(c_buf)
            else:
                c_buf = bytes(data)
                ptr = c_buf
        max_out = 512
        offs = (ctypes.c_uint32 * max_out)()
        kinds = (ctypes.c_uint8 * max_out)()
        cnt = cpp_core.lib().ali_scan_code(ptr, n, offs, kinds, max_out, mask)
        if cnt > max_out:
            if mask & 1:
                self._find_lzma_decoders(data, base, views)
            if mask & 2:
                self._find_delay_routines(data, base, views)
            if mask & 4:
                self._find_poll_loops(data, base, views)
            return
        for i in range(cnt):
            off = int(offs[i])
            k = int(kinds[i])
            sub = data[off:min(n, off + 256)]
            if k == 1:
                self._find_lzma_decoders(sub, base + off, views)
            elif k == 2:
                self._find_delay_routines(sub, base + off, views)
            elif k == 3:
                self._find_poll_loops(sub, base + off, views)

    def _rescan_cp0_sites(self, ranges=None):
        """No CP0 sites on this core: only LzmaDecode() (and the RTOS's delay(), when
        delay_hle is on) is looked for, in the flash image or the given ranges."""
        if ranges is None:
            if self._rom_sites_dirty:
                self._rom_sites_dirty = False
                rom_crc = (len(self.rom_image), zlib.crc32(self.rom_image))
                if self.__dict__.get('_rom_scanned_crc') != rom_crc:
                    self._rom_scanned_crc = rom_crc
                    self._cpp_scan_code(self.rom_image, 0, (0xAFC00000, 0xBFC00000, 0x8FC00000, 0x9FC00000),
                                        want_lzma=True, want_delay=False, want_poll=False)
            ranges = self.chip.code_ranges()
        ram_base_ptr = ctypes.addressof(self.ram_buffer)
        for start, length in ranges:
            phys = start & 0x1FFFFFFF
            in_ram = (start >> 29) in (0, 4, 5) and phys + length <= self._mapped_ram_size
            ram_bytes = None
            ptr = None
            if in_ram:
                data = self._ram_view[phys:phys + length]
                ptr = ram_base_ptr + phys
                if length >= self._VIRGIN_CHUNK:
                    ram_bytes = zlib.crc32(data)
                    if self._scanned_ram_chunks.get((phys, length, False)) == ram_bytes:
                        continue
            else:
                try:
                    data = self.mu.mem_read(start, length)
                except UcError:
                    continue
            if (start >> 29) in (4, 5):
                self._cpp_scan_code(data, phys, (0x80000000, 0xA0000000), ptr=ptr)
            if ram_bytes is not None:
                self._scanned_ram_chunks[(phys, length, False)] = ram_bytes

    def _cpp_hook_code(self, uc, address, size, user_data):
        """Exact mode: the per-instruction bookkeeping of the Python engine's
        _hook_code (history, visit counts, sizes, ISA, trace); the core does the
        rest itself."""
        m16 = size == 2 or uc.hook_m16 == 1          # (passed with the hook: no read-back per instruction)
        self.prev_executed_pc = self.current_executed_pc
        self.current_executed_pc = address
        self._last_hook_size, self._last_hook_addr = size, address
        self.pc_history.append(address)
        if len(self.pc_history) > self.history_size:
            self.pc_history.pop(0)
        self.visit_counts[address] = self.visit_counts.get(address, 0) + 1
        self.instruction_sizes[address] = size
        self.instruction_isa[address] = m16
        if self.trace_instructions:
            try:
                insn = bytes(uc.mem_read(address, size))
                loop_str = f" [LOOP {self.visit_counts[address]}]" if self.visit_counts[address] > 1 else ""
                bytes_str = ' '.join(f'{b:02x}' for b in insn)
                if m16:
                    from mips16_decoder import MIPS16Decoder
                    mnemonic, operands = MIPS16Decoder.decode(insn, address)
                    self.log(f"0x{address:08X}: {bytes_str:<15} {mnemonic}\t{operands}{loop_str}")
                else:
                    for i in self.md.disasm(insn, address):
                        self.log(f"0x{i.address:08X}: {bytes_str:<15} {i.mnemonic}\t{i.op_str}{loop_str}")
            except Exception:
                pass

    # ------------------------------------------------------------------
    # Running
    # ------------------------------------------------------------------
    def _raise_core_error(self):
        err = self._core.get(F_LAST_ERROR)
        pc = self._core.get(F_FAULT_PC)
        self.log(f"Core error {err} at PC=0x{pc:08X} (address 0x{self._core.get(F_FAULT_ADDR):08X})")
        e = UcError(err)
        self._log_unicorn_error(e)
        raise e

    def _core_run(self, limit, idle):
        """One slice on the core: until its instruction count reaches limit.
        Returns (stop reason, instructions executed)."""
        core = self._core
        if self._gpio_di_owners:
            self._cpp_gpio_busy_sync()
        idle_val = 1 if idle else 0
        if idle_val != self._idle_skip_pushed:
            self._idle_skip_pushed = idle_val
            core.set(F_IDLE_SKIP, idle_val)
        e0 = core.get(F_EXECUTED)
        r = core.run(limit)
        return r, core.get(F_EXECUTED) - e0

    def run(self, max_instructions=None, max_vtime=None):
        """As AliMipsSimulator.run: until max_instructions (instruction_count) or
        the emulation time max_vtime."""
        if max_instructions is not None:
            self.max_instructions = max_instructions
        core = self._core
        cur_pc = self.mu.reg_read(UC_MIPS_REG_PC)
        if self._shared is None or max_vtime is None:
            note = "" if self._want_full_hook() else " [C++ core: instruction counts follow emulation time]"
            self.log(f"Starting emulation at {hex(cur_pc)} ({'MIPS16' if self.is_mips16_mode() else 'MIPS32'})...{note}")
        self._in_run = True
        self._run_tid = threading.get_ident()
        self._external_stop = False
        self._run_max_vtime = max_vtime
        _last_progress = None
        _stall_slices = 0
        try:
            while True:
                if self._external_stop:
                    break
                if self.max_instructions and self.instruction_count >= self.max_instructions:
                    break
                if max_vtime is not None and self._vtime() >= max_vtime:
                    break
                _prog = (self.instruction_count, self._vtime(), cur_pc)
                if _prog == _last_progress:
                    _stall_slices += 1
                    if _stall_slices >= 64:
                        raise RuntimeError(
                            f"Emulation stalled with zero progress at PC=0x{cur_pc:08X} "
                            f"(stop_reason={self._stop_reason!r})"
                        )
                else:
                    _last_progress = _prog
                    _stall_slices = 0
                if cur_pc in self.breakpoints or (self.stop_instr is not None and cur_pc == self.stop_instr):
                    self.step()
                    cur_pc = self.mu.reg_read(UC_MIPS_REG_PC)
                    if self.max_instructions and self.instruction_count >= self.max_instructions:
                        break
                    if (cur_pc & ~1) == 0:
                        break
                if self._irc_frames:
                    self._irc_service()
                for service in self.slice_services:
                    service()
                if self.busy_pending > 1e-9 and not self._want_full_hook() and self._skip_busy(max_vtime):
                    continue
                self._cpp_sync()
                full = self._exact_hook is not None
                if not full and self.poll_skip and self._skip_poll(cur_pc, max_vtime):
                    continue
                budget = self._budget()
                self._stop_reason = None
                icount = core.get(F_ICOUNT)
                if full:
                    # exact mode: instruction_count is the core's executed count
                    n = budget if budget is not None else self.batch_size
                    if max_vtime is not None:
                        n = min(n, max(1, int((max_vtime - self._vtime()) * self.cpp_ips)))
                    r, executed = self._core_run(icount + max(1, n), False)
                    self.instruction_count += executed
                else:
                    small = budget is not None and budget <= self.exact_count_threshold
                    calibrating = self._counted_slices < self.calibration_slices
                    if self._timeout_slices == 0 and (small or calibrating):
                        batch = max(1, self.batch_size if budget is None else min(self.batch_size, budget))
                        if max_vtime is not None:
                            batch = max(1, min(batch, int((max_vtime - self._vtime()) * self.cpp_ips) + 1))
                        r, executed = self._core_run(icount + batch, False)
                        self.instruction_count += executed
                        self._counted_slices += 1
                    else:
                        slice_s = self.batch_timeout_us / 1e6
                        due = self._services_due()
                        if due is not None:
                            slice_s = min(slice_s, max(due - self._vtime(), self.SERVICE_MIN_SLICE_S))
                        if budget is not None:
                            slice_s = min(slice_s, budget / self._insn_rate)
                        if max_vtime is not None:
                            slice_s = min(slice_s, max(0.0, max_vtime - self._vtime()))
                        n = max(1, int(round(slice_s * self.cpp_ips)))
                        self._cpp_slice_end = (icount + n) / self.cpp_ips
                        try:
                            r, _executed = self._core_run(icount + n, self.idle_skip)
                        finally:
                            self._cpp_slice_end = None
                        dt = (core.get(F_ICOUNT) - icount) / self.cpp_ips
                        counted = int(self._insn_rate * dt)
                        if budget is not None:
                            counted = min(counted, budget)
                        if r == STOP_COUNT and budget is not None and slice_s >= budget / self._insn_rate - 1e-12:
                            counted = budget        # (the slice was the rest of the budget)
                        self.instruction_count += counted
                        self._timeout_slices += 1
                core._raise_pending()
                if self._rom_dirty:
                    self._rom_restore()
                if r == STOP_ERROR:
                    self._raise_core_error()
                cur_pc = self.mu.reg_read(UC_MIPS_REG_PC)
                if (cur_pc & ~1) == 0 or self._stop_reason == 'null':
                    self.log("[!] Stopped: Jump to NULL")
                    break
                if r == STOP_BREAKPOINT:
                    if self.stop_instr is not None and cur_pc == self.stop_instr:
                        self.log(f"\n[STOP] Reached stop address: 0x{cur_pc:08X}")
                        self._stop_reason = 'stop_instr'
                    else:
                        self.log(f"\n[BREAKPOINT] Hit at 0x{cur_pc:08X}")
                        self._stop_reason = 'breakpoint'
                    break
                if self._stop_reason == 'external' or self._external_stop:
                    break
        except UcError:
            raise
        except Exception as e:
            import traceback
            self.log(f"Error: {e}")
            self.log(traceback.format_exc())
            raise
        finally:
            self._in_run = False
            self._run_max_vtime = None

    def _exec_one(self, pc):
        """Exactly one instruction at pc (no interrupt: the next run() takes it; a
        breakpoint there is stepped over)."""
        core = self._core
        self._cpp_sync()
        core.set(F_IRQS_ENABLED, 0)
        core.set(F_STEP_OVER_BP, 1)
        self.is_stepping = True
        self._stop_reason = None
        e0 = core.get(F_EXECUTED)
        try:
            cpp_core.CppUc.emu_start(core, self._start_pc(pc), 0xFFFFFFFFFFFFFFFF, 0, 1)
            if core.get(F_DS_ACTIVE):
                # a branch: its delay slot too, as a step on Unicorn does (it cannot stop between them)
                cpp_core.CppUc.emu_start(core, core.get(F_PC_MODE), 0xFFFFFFFFFFFFFFFF, 0, 1)
        finally:
            self.is_stepping = False
            core.set(F_IRQS_ENABLED, 1)
            core.set(F_STEP_OVER_BP, 0)
            self.instruction_count += core.get(F_EXECUTED) - e0
            if self._rom_dirty:
                self._rom_restore()

    def _log_unicorn_error(self, e):
        try:
            pc = self.mu.reg_read(UC_MIPS_REG_PC)
            m16 = self.is_mips16_mode()
            self.log(f"Core error: {e}")
            self.log(f"PC at error: {hex(pc)} ({'MIPS16' if m16 else 'MIPS32'})")
            self.log(f"Status at error: {hex(self.cp0_status)}")
            mnemonic, operands, sz = self._decode_for_display(pc, m16)
            raw = bytes(self.mu.mem_read(pc, sz)).hex()
            self.log(f"Instruction at PC: {raw} {mnemonic} {operands}")
        except Exception:
            pass
