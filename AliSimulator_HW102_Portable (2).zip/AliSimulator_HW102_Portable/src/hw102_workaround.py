"""HW102's firmware-derived IR profile and exact-image gate fallback.

Two known image containers carry the same byte-for-byte HW102 build-5079
maincode. The normal C3503C path supplies the missing OTP self-check record
through the image's sidecar, so firmware clears its own input gate without a
RAM edit. This module retains the firmware-derived IR map and the old exact-
image RAM bypass as an optional fallback, off by default in the TV GUI.
"""
from __future__ import annotations

import hashlib
import os

from uc_const import UC_MIPS_REG_GP


HW102_SHA1 = "b1572174fac6da422591b6e9049a9696049af0cd"
HW102_REPOSITORY_DUMP_SHA1 = "abca1371e892857ccb5dfca478a464a37dc1c9d1"
HW102_GATE_GP_OFFSET = 0x6E68
HW102_IR_CODING = "ext00"

# Exact outer-image hashes for the two known containers of this firmware.
# The GitHub-linked dump has different non-maincode bytes, but its extracted
# 9,773,336-byte maincode was compared byte-for-byte with the HW102 ABS image.
_HW102_IMAGE_SIDECARS = {
    HW102_SHA1: "HW102.02.999-V-5079-By-www.receiveroption.com.abs.json",
    HW102_REPOSITORY_DUMP_SHA1: "dump202611220911.abs.json",
}

# {firmware VKEY: 16-bit IR table code}. Extracted from the HW102 profile
# 0x4040 at 0x8090D154 and validated by dynamic dispatch. Entries with a
# duplicate VKEY retain the first profile row, matching the firmware scanner.
# ir_remote.frame_from_ir16(code, "ext00") turns each into its tested NEC frame.
HW102_IR_KEY_TABLE = {
    0: 0x40FF, 1: 0x407F, 2: 0x40BF, 3: 0x403F, 4: 0x40DF,
    5: 0x405F, 6: 0x409F, 7: 0x401F, 8: 0x40EF, 9: 0x406F,
    10: 0x40F7, 11: 0x4077, 12: 0x402F, 13: 0x408F, 14: 0x404F,
    15: 0x40FD, 16: 0x40BD, 19: 0x40AF, 20: 0x400F,
    21: 0x4027, 22: 0x4047, 23: 0x40CF, 24: 0x40D5, 26: 0x40A5,
    29: 0x407D, 36: 0x4057, 37: 0x40C7, 38: 0x4007, 39: 0x4087,
    42: 0x40A7, 43: 0x4025, 44: 0x4035, 45: 0x4015, 46: 0x405D,
    49: 0x40C5, 50: 0x4097, 53: 0x4097, 54: 0x4017, 55: 0x40E7,
    56: 0x4067, 60: 0x40ED, 61: 0x40D7, 63: 0x4037, 65: 0x409D,
    66: 0x40B7, 67: 0x401D, 68: 0x403D, 75: 0x40E7, 82: 0x40AD,
    86: 0x40DD,
}

_IMAGE_MATCH_CACHE = {}


def _hw102_sidecar_name(path: str | os.PathLike | None):
    """Return a bundled sidecar filename for a recognized exact image, or None."""
    if not path:
        return None
    try:
        path = os.path.realpath(os.fspath(path))
        st = os.stat(path)
    except (OSError, TypeError, ValueError):
        return None
    cache_key = (path, st.st_size, st.st_mtime_ns)
    if cache_key in _IMAGE_MATCH_CACHE:
        return _IMAGE_MATCH_CACHE[cache_key]
    digest = hashlib.sha1()
    try:
        with open(path, "rb") as f:
            for block in iter(lambda: f.read(1024 * 1024), b""):
                digest.update(block)
    except OSError:
        return None
    sidecar = _HW102_IMAGE_SIDECARS.get(digest.hexdigest())
    _IMAGE_MATCH_CACHE[cache_key] = sidecar
    return sidecar


def is_hw102_image(path: str | os.PathLike | None) -> bool:
    """Return True only for either of the two SHA-1-verified HW102 containers."""
    return _hw102_sidecar_name(path) is not None


def bundled_sidecar_for_image(path: str | os.PathLike | None) -> str | None:
    """Return the matching bundled sidecar for a recognized image.

    The GUI uses this only when a user browses to an exact known image stored
    outside the project and that file has no adjacent JSON sidecar.
    """
    name = _hw102_sidecar_name(path)
    if name is None:
        return None
    root = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
    candidate = os.path.join(root, "dumps", name)
    return candidate if os.path.isfile(candidate) else None


def install_hw102_ir_profile(sim):
    """Install the validated HW102 key table and extended-NEC coding.

    The profile table is image-specific because this firmware keeps 14-byte
    records that the generic 8-byte RAM scanner does not recognize. This does
    not touch the firmware's gate or any guest memory.
    """
    if not is_hw102_image(getattr(sim, "dump_path", None)):
        return False
    sim._ir_key_table = dict(HW102_IR_KEY_TABLE)
    sim.ir_coding = HW102_IR_CODING
    return True


def apply_input_workaround(sim):
    """Apply the legacy exact-image gate bypass as an explicit fallback.

    The normal fix is the HW102 sidecar's OTP 0x1c0 record, consumed by the
    C3503 OTP controller model. This function is retained for diagnostics or
    a user-selected fallback only; the TV GUI leaves it off by default.
    Returns diagnostic details, or ``None`` for any other image.
    """
    if not install_hw102_ir_profile(sim):
        return None

    try:
        mu = getattr(sim, "mu", None)
        gp = int(mu.reg_read(UC_MIPS_REG_GP)) & 0xFFFFFFFF
        gate_addr = (gp - HW102_GATE_GP_OFFSET) & 0xFFFFFFFF
        ram_start = 0x80000000
        ram_end = ram_start + int(sim.ram_size)
        if gate_addr < ram_start or gate_addr + 4 > ram_end:
            return {"ok": False, "reason": "GP-derived gate address is outside guest RAM",
                    "gp": gp, "gate_address": gate_addr}
        before = bytes(sim.peek(gate_addr, 4))
        sim.poke(gate_addr, b"\0\0\0\0")
        after = bytes(sim.peek(gate_addr, 4))
        return {
            "ok": after == b"\0\0\0\0",
            "gp": gp,
            "gate_address": gate_addr,
            "gate_before": int.from_bytes(before, "little"),
            "gate_after": int.from_bytes(after, "little"),
        }
    except Exception as exc:
        return {"ok": False, "reason": f"could not clear the input gate: {exc}",
                "gp": None, "gate_address": None}
