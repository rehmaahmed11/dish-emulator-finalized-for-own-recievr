"""
ALi M3821 family (M3821 / M3822P, the DVB-T2 generation: the Opticum Blue
R265 Lite dump).  The flash has the same NCRC chunk chain as the M3801's and
is memory-mapped at 0xAFC00000 like there, but the bootloader chunk is built
for an on-chip boot ROM:

  * the chunk's version string is "M3821b-0.1.0" (that is how the family is
    recognised);
  * offset 0x470.. holds a descriptor table the boot ROM interprets (a
    register script: clock registers at 0xB8001000.., the DDR controller at
    0xB803E02C..), not code;
  * the bootloader itself starts at offset 0x800 and expects to run from a
    boot SRAM at physical 0x1FE00000 (KSEG0 0x9FE00000: its stack sits at
    0x9FE04000 and it jumps to 0x9FE02488), so the boot ROM copies the
    bootloader area there and enters at 0x9FE00800.

Once there it prints "NOR1" on the UART (the same 16550 at 0xB8018300),
programs the clock tree, trains the DDR controller (0xB803E000..) and copies
the next stage from the flash window into RAM (its "HEAD" record at flash
offset 0x250: load address 0xA1000000).  The simulator's RAM needs no
training, so the DDR model only answers the status and pattern words the
training loop checks (DdrTraining).

The application (ALi SDK 4.0, "libcore 19.9") wants the chip ID word at
0xB8000000 to carry the M3822P variant bits (chip_variant), moves the
exception vectors with CP0 EBase, and talks to the flash through the SPI
controller's byte-stream mode and DMA engine (SpiStream) instead of the
M3801 driver's SF_INS command register.  Its start-up runs its large
memory copies through an 8-channel descriptor-ring DMA engine (DmaRings)
and fills the sound engine's PCM ring, whose read index must follow the
write index (MirrorRegisters); then it draws its OSD through the same
graphics engine (0xB800A000, ge_m36f.py) and display layer (0xB8006300,
gma_capture.py) as the M3801 boxes, so nothing of the display is this
family's own.  Firmware 1.2.0's application also waits, before it draws,
for a start bit it sets in the block at 0xB802A000 to clear (install(); most
likely the HDMI transmitter's DDC reading the TV's EDID: the block's +0x08
bit 0 is polled like a hot-plug line and the flash carries an HDCPKey
chunk).  Demodulator models the internal DVB-T / T2 demodulator's lock for
sim.set_signal().

The Ferguson T750i's M3821 boots without the boot ROM's step: its
bootloader is the M3801's kind, run from the flash window (a branch over
the chunk header, code at 0x490), with its stack in locked D-cache lines
until the DDR is up (CacheAsRam) and its set-up run through the window's
cached view; it takes its M3821 path for the chip ID 0x3821 (the plain
M3821, revision B in the low byte), starts the SEE co-processor (see.py) and
unpacks the main code and the SEE's program from its dual-CPU image.  Such an image
is recognised by that bootloader, a SEE program chunk and a main code that
drives the M3821's own demodulator ("NIM_S3821").
"""
import ctypes
import struct

from uc_const import UC_HOOK_CODE, UC_PROT_ALL, UC_MIPS_REG_PC, UC_MIPS_REG_SP

from .base import ChipFamily, DemodulatorLock, ReadyBits, chunk_chain, maincode, word_after_store
from .see import SeeStart

SRAM_PHYS = 0x1FE00000          # the boot SRAM the boot ROM copies the bootloader into
SRAM_SIZE = 0x100000
BOOT_COPY = 0x60000             # the bootloader area of the flash (its chunk: 0..0x5FE00)
ENTRY = 0x80000000 + SRAM_PHYS + 0x800


def xip_bootloader(image):
    """A bootloader that runs from the flash window (the M3801's kind): its
    word at 0x490, where the chunk header's branch lands, calls into the
    flash window (JAL 0x?FCxxxxx)."""
    if len(image) < 0x494:
        return False
    w = struct.unpack_from("<I", image, 0x490)[0]
    return w >> 26 == 0x03 and ((w & 0x03FFFFFF) << 2) & 0x0FC00000 == 0x0FC00000


class CacheAsRam:
    """The stack of an XIP bootloader before the DDR is up (the T750i's): it
    loads the D-cache lines of 0x8FFF8000..0x8FFFFFFF -- the top of the flash
    window's cached view -- and keeps its stack there (and its DDR set-up
    functions locked in the I-cache), so stores to those addresses stay in
    the cache and loads see them.  The simulator has no cache: 32 KB of RAM
    over that range, holding the flash's bytes, given back the flash's bytes
    once the bootloader runs from RAM with its stack elsewhere (its RAM copy
    reads nothing there through the cache)."""
    PHYS, SIZE = 0x0FFF8000, 0x8000

    def __init__(self, sim):
        self.sim = sim
        self.flash = bytes(sim.mu.mem_read(self.PHYS, self.SIZE))
        self.ram = ctypes.create_string_buffer(self.flash, self.SIZE)
        sim.mu.mem_unmap(self.PHYS, self.SIZE)
        sim.mu.mem_map_ptr(self.PHYS, self.SIZE, UC_PROT_ALL, ctypes.addressof(self.ram))
        self.active = True
        self._hook = sim.mu.hook_add(UC_HOOK_CODE, self._code_in_ram, begin=0x80000000,
                                     end=0x80000000 + min(sim.ram_size, 0x0F000000) - 1)

    def _code_in_ram(self, uc, address, size, user_data):
        sp = uc.reg_read(UC_MIPS_REG_SP) & 0x1FFFFFFF
        if self.PHYS <= sp < self.PHYS + self.SIZE:
            return                      # (still on the cache's stack)
        ctypes.memmove(self.ram, self.flash, self.SIZE)     # host memory: no translation to flush
        uc.hook_del(self._hook)
        self.active = False
        self.sim.log(f"[CAR] the bootloader runs from RAM (0x{address:08X}, sp 0x{sp | 0x80000000:08X}): "
                     f"0x8FFF8000..0x8FFFFFFF show the flash again")

    def remove(self):
        """The flash's own mapping back over the range (a chip-family switch)."""
        if self.active:
            self.sim.mu.hook_del(self._hook)
            self.active = False
        self.sim.mu.mem_unmap(self.PHYS, self.SIZE)
        self.sim._map_flash_mirror(self.PHYS, self.SIZE)


class DdrTraining:
    """The DDR controller's training status at 0xB803E08C.. and the pattern
    capture words at 0xB803E090.. (one 32-byte block per byte lane) the
    bootloader reads while it sweeps the delay taps of each lane
    (0xB803E02E + lane, 0xB803E082 + lane, 0xB803E034 / 38, applied with bit 7
    of 0xB803E03B / 3F): it keeps a setting when the status says locked and the
    captured words are its test patterns (bootloader 0x9FE00B20; lane 0 is
    compared against different words than the other lanes).  The simulator's
    RAM always reads back what was written, so the model is the answers only."""
    STATUS = 0x3E08C            # bits 8..0 = 2 * delay taps, bits 31..30 = locked
    CAPTURE = 0x3E090           # + lane * 0x20 + word * 4
    LANES = 4
    TAPS = 32
    PATTERNS_LANE0 = (0x0FF00FF0, 0xFF00FF00, 0x00FF00FF, 0xF00FF00F,
                      0x0FF00FF0, 0x00FF00FF, 0xFF00FF00, 0x0FF00FF0)
    PATTERNS_OTHER = (0xA55AA55A, 0xFF00FF00, 0x00FF00FF, 0x5AA55AA5,
                      0xA55AA55A, 0x00FF00FF, 0xFF00FF00, 0xA55AA55A)

    def __init__(self, sim):
        self.sim = sim
        view = getattr(sim, "_mmio_view", None)
        if view is not None:
            view[self.STATUS:self.STATUS + 4] = (0xC0000000 | (2 * self.TAPS)).to_bytes(4, 'little')
            for lane in range(self.LANES):
                patterns = self.PATTERNS_LANE0 if lane == 0 else self.PATTERNS_OTHER
                for word, val in enumerate(patterns):
                    off = self.CAPTURE + lane * 0x20 + word * 4
                    view[off:off + 4] = val.to_bytes(4, 'little')
        sim._mmio_on('r', self._read_status, self.STATUS, self.STATUS + 3)
        sim._mmio_on('r', self._read_capture, self.CAPTURE, self.CAPTURE + self.LANES * 0x20 - 1)

    def _read_status(self, uc, access, address, size, value, user_data):
        word = 0xC0000000 | (2 * self.TAPS)
        uc.mem_write(0xB8000000 + self.STATUS, word.to_bytes(4, 'little'))

    def _read_capture(self, uc, access, address, size, value, user_data):
        off = (address & 0xFFFFFF) - self.CAPTURE
        lane, word = off >> 5, (off & 0x1F) >> 2
        patterns = self.PATTERNS_LANE0 if lane == 0 else self.PATTERNS_OTHER
        uc.mem_write(address & ~3, patterns[word].to_bytes(4, 'little'))


class SpiStream:
    """The byte-stream mode of the M3821's SPI flash controller (base
    0xB802E000), which the application's flash driver uses for everything but
    memory-mapped reads.  With bits 26..25 of the register at +0xC8 set (the
    application sets and clears 26..24, the 2023 bootloader keeps 24) the
    controller holds the chip select and the flash window becomes a byte
    stream: every store clocks its bytes out to the part (the command, then
    address and data bytes), every load clocks reply bytes in, and clearing
    the bits ends the transaction (a program or erase takes effect then).
    Transfers of 256 bytes and more go through the controller's DMA engine:
    the RAM address at +0x58, the length at +0x60, a control word at +0x64
    whose write starts it (bit 7: RAM to part, else part to RAM), and bit 0
    of the status at +0xA0 (write 1 to clear) once it is done.  SF_INS / FMT /
    DUM / CFG stay in normal read mode throughout, so the simulator's flash
    window hooks defer to this stream while it is on (simulator._spi_stream)."""
    MODE, MODE_BITS = 0x2E0C8, 0x06000000      # (the 2023 bootloader leaves bit 24 set between transactions)
    DMA_ADDR, DMA_LEN, DMA_CTRL, DMA_STATUS = 0x2E058, 0x2E060, 0x2E064, 0x2E0A0
    DMA_TO_PART = 0x80
    # commands with 3 address bytes -> dummy bytes between the address and the data
    ADDRESSED = {0x03: 0, 0x0B: 1, 0x3B: 1, 0x6B: 1, 0x02: 0, 0x32: 0, 0x20: 0, 0x52: 0, 0xD8: 0}
    READS = (0x03, 0x0B, 0x3B, 0x6B)

    def __init__(self, sim):
        self.sim = sim
        self.active = False
        self.dma_done = False
        self._reset()
        sim._mmio_on('w', self._write_mode, self.MODE, self.MODE + 3)
        sim._mmio_on('w', self._write_dma_ctrl, self.DMA_CTRL, self.DMA_CTRL + 3)
        sim._mmio_on('w', self._write_dma_status, self.DMA_STATUS, self.DMA_STATUS + 3)
        sim._mmio_on('r', self._read_dma_status, self.DMA_STATUS, self.DMA_STATUS + 3)
        sim._spi_stream = self

    def _reset(self):
        self.tx = bytearray()       # what went out so far
        self.rx = 0                 # how much came in so far
        self._parsed_hdr = None

    def _parse_hdr(self):
        """(command, flash address, header length) cached for the current tx."""
        if self._parsed_hdr is not None:
            return self._parsed_hdr
        if not self.tx:
            return None, 0, 0
        cmd = self.tx[0]
        dummy = self.ADDRESSED.get(cmd)
        if dummy is None:
            res = (cmd, 0, 1)
        else:
            res = (cmd, int.from_bytes(self.tx[1:4], 'big'), 4 + dummy)
        self._parsed_hdr = res
        return res

    def _parse(self):
        """(command, flash address, data bytes) of the transaction so far."""
        cmd, addr, hdr_len = self._parse_hdr()
        if cmd is None:
            return None, 0, b""
        return cmd, addr, bytes(self.tx[hdr_len:])

    def write(self, data):
        """Bytes the firmware clocks out: a store to the window or a DMA from RAM."""
        self.tx += data
        self._parsed_hdr = None

    def read(self, n):
        """The next n bytes the part clocks in: flash contents from the address
        of a read command, the reply to an ID / status command, else idle."""
        cmd, addr, _ = self._parse_hdr()
        start, self.rx = self.rx, self.rx + n
        if cmd in self.READS:
            rom, size = self.sim.rom_image, self.sim.rom_size
            first = (addr + start) % size
            if first + n <= size:
                return bytes(rom[first:first + n])
            return bytes(rom[(first + i) % size] for i in range(n))
        reply = self.sim._spi_command_response(cmd) if cmd is not None else []
        return bytes(reply[i] if i < len(reply) else 0x00 for i in range(start, start + n))

    def _end(self):
        if self.sim._rom_dirty:
            self.sim._rom_restore()
        cmd, addr, data = self._parse()
        if cmd is not None:
            self.sim._spi_log(f"STREAM 0x{cmd:02X} ({self.sim._SPI_CMD_NAMES.get(cmd, 'Unknown')})"
                              f" @ 0x{addr:06X}: {len(data)} B out, {self.rx} B in")
            if cmd not in self.READS:
                self.sim._spi_execute(cmd, addr, data)
        self._reset()

    def _write_mode(self, uc, access, address, size, value, user_data):
        # The register as the store leaves it: the application writes the word, the
        # 2023 bootloader only its top byte.
        old = int.from_bytes(uc.mem_read(0xB8000000 + self.MODE, 4), 'little')
        word = word_after_store(old, address, self.MODE, size, value)
        on = bool(word & self.MODE_BITS)
        if on == self.active:
            return                  # (also the replay of this store after the hook change below)
        self.active = on
        if on:
            self._reset()
        else:
            self._end()
        if hasattr(self.sim, "_cpp_spi_sync"):
            self.sim._cpp_spi_sync()
        self.sim._update_flash_read_hooks()     # the window's hooks follow the mode

    def _write_dma_ctrl(self, uc, access, address, size, value, user_data):
        sim = self.sim
        if not value or sim._dev_replay_of(uc, 'spi_dma', address, value) is not None:
            return                  # cleared after a transfer, or this store replayed after a stop at it
        sim._dev_note(uc, 'spi_dma', address, value)
        ram = 0x80000000 + (int.from_bytes(sim.peek(0xB8000000 + self.DMA_ADDR, 4), 'little') & 0x1FFFFFFF)
        length = int.from_bytes(sim.peek(0xB8000000 + self.DMA_LEN, 4), 'little')
        if value & self.DMA_TO_PART:
            self.write(bytes(sim.mu.mem_read(ram, length)))
        else:
            sim.mu.mem_write(ram, self.read(length))
        self.dma_done = True

    def _write_dma_status(self, uc, access, address, size, value, user_data):
        if value & 1:
            self.dma_done = False

    def _read_dma_status(self, uc, access, address, size, value, user_data):
        uc.mem_write(0xB8000000 + self.DMA_STATUS, int(self.dma_done).to_bytes(4, 'little'))


class DmaRings:
    """The 8-channel descriptor-ring DMA engine at 0xB800F000 the firmware's
    large memory copies go through.  Per channel: the ring's physical base at
    +0x00 + 4 * ch (16-byte descriptors: source, destination, flags | length - 1,
    0), its length minus one at +0x20 + ch, the ring index after the last
    descriptor submitted written to +0x28 + ch, and the index the engine has
    reached read back from +0x30 + ch, which the firmware polls (with 100 us
    delays) until it equals what it submitted; +0x48 / +0x4A hold the channels'
    enable bits.  (The block the M3801 SDK calls VCAP_M36F: bit 0 of its +0x4B
    is the self-clearing reset the simulator answers for every chip,
    _SELF_COMPLETING.)  The simulator copies a descriptor's bytes the moment it
    is submitted.

    The M36xx has the same engine at 0xB800F200 (the SDK's dma_s3601: list
    base / length / write / read index at the same offsets), whose first
    SC_CHANNELS channels can also find start codes in what they copy
    (start_codes): a descriptor with bit 29 set (dma_copy's flag 0x20) has the
    copied bytes searched for 00 00 01 xx, and the physical address of each
    xx byte goes into the channel's start-code ring (base +0x60 + 4 * ch, its
    length in entries +0x70 + 2 * ch, the engine's write index +0x80 + 2 * ch,
    the driver's read index +0x78 + 2 * ch), unless the code lies in the
    channel's range (+0x88 + 2 * ch: first, last; the video decoder's 0x02 ..
    0xB1 leaves out its slices) -- or, with the channel's bit of +0x4F set,
    outside it.  The SEE library's video decoder reads those entries in its
    buffer updates (vdec_vbv_update_write_p -> dma_get_start_code) to find
    its pictures.  (No image has fed the engine in the simulator so far; the
    single-CPU M3601E's decoder parses its buffer itself.)"""
    RING, RING_LEN, SUBMIT, DONE = 0x00, 0x20, 0x28, 0x30
    SC_ENABLE, SC_RANGE_INSIDE = 0x4C, 0x4F
    SC_BASE, SC_LEN, SC_READ, SC_WRITE, SC_RANGE = 0x60, 0x70, 0x78, 0x80, 0x88
    CHANNELS, SC_CHANNELS = 8, 4
    SC_FLAG = 1 << 29

    def __init__(self, sim, base=0xF000, start_codes=False):
        self.sim = sim
        self.BASE = base
        self.start_codes = start_codes
        self.done = [0] * self.CHANNELS
        self.tail = [b""] * self.CHANNELS        # (end address, last 3 bytes) of each channel's last scanned copy
        self.submissions = 0            # logged ones
        self.codes = 0                  # start codes found
        self.wire(sim)

    def wire(self, core):
        """The engine's registers among a core's device handlers (the SEE core
        of a dual-CPU chip feeds the engine too: its video decoder)."""
        b = self.BASE
        if not hasattr(self, "_wired_cores"):
            self._wired_cores = []
        if core not in self._wired_cores:
            self._wired_cores.append(core)
        view = getattr(core, "_mmio_view", None)
        if view is not None:
            view[b + self.DONE:b + self.DONE + self.CHANNELS] = bytes(self.done)
        core._mmio_on('w', self._write_submit, b + self.SUBMIT, b + self.SUBMIT + self.CHANNELS - 1)
        core._mmio_on('r', self._read_done, b + self.DONE, b + self.DONE + self.CHANNELS - 1)

    def _reg(self, offset, size):
        return int.from_bytes(self.sim.peek(0xB8000000 + self.BASE + offset, size), 'little')

    def _write_submit(self, uc, access, address, size, value, user_data):
        sim = self.sim
        for i in range(size):                       # (a word write submits to several channels)
            ch = (address & 0xFFFFFF) - self.BASE - self.SUBMIT + i
            if not 0 <= ch < self.CHANNELS:
                continue
            count = (value >> (8 * i)) & 0xFF
            ring = self._reg(self.RING + 4 * ch, 4) & 0x0FFFFFF0
            length = self._reg(self.RING_LEN + ch, 1) + 1
            while self.done[ch] != count:
                desc = sim.peek(0x80000000 + ring + 16 * (self.done[ch] % length), 16)
                src, dst, word = (int.from_bytes(desc[o:o + 4], 'little') for o in (0, 4, 8))
                src, dst, n = src & 0x0FFFFFFF, dst & 0x0FFFFFFF, (word & 0x1FFFFFFF) + 1
                ok = max(src, dst) + n <= sim._mapped_ram_size
                if self.submissions < 16:
                    self.submissions += 1
                    sim.log(f"[DMA] ch{ch} #{self.done[ch]}: 0x{src:08X} -> 0x{dst:08X}, {n} bytes (ring 0x{ring:08X} x{length})"
                            + ("" if ok else " -- outside RAM, skipped"))
                if ok:
                    data = bytes(sim.mu.mem_read(0x80000000 + src, n))
                    sim.mu.mem_write(0x80000000 + dst, data)
                    if self.start_codes and word & self.SC_FLAG and ch < self.SC_CHANNELS:
                        self._find_start_codes(ch, dst, data)
                self.done[ch] = (self.done[ch] + 1) & 0xFF
            for c in getattr(self, "_wired_cores", (sim,)):
                v = getattr(c, "_mmio_view", None)
                if v is not None:
                    v[self.BASE + self.DONE + ch] = self.done[ch]

    def _find_start_codes(self, ch, dst, data):
        """Append the start codes in a copy (and across its start, from the
        channel's previous copy if this one follows it) to the channel's ring."""
        if not self._reg(self.SC_ENABLE, 1) >> ch & 1:
            return
        end, tail = self.tail[ch] or (None, b"")
        prefix = tail if end == dst else b""
        self.tail[ch] = (dst + len(data), (prefix + data)[-3:])
        buf = prefix + data
        first, last = self._reg(self.SC_RANGE + 2 * ch, 1), self._reg(self.SC_RANGE + 2 * ch + 1, 1)
        inside = self._reg(self.SC_RANGE_INSIDE, 1) >> ch & 1
        ring = self._reg(self.SC_BASE + 4 * ch, 4) & 0x0FFFFFF0
        length = self._reg(self.SC_LEN + 2 * ch, 2)
        if not ring or not length:
            return
        write = self._reg(self.SC_WRITE + 2 * ch, 2)
        read = self._reg(self.SC_READ + 2 * ch, 2)
        i = buf.find(b"\x00\x00\x01")
        while 0 <= i < len(buf) - 3:
            code = buf[i + 3]
            if (first <= code <= last) == bool(inside):
                if (write + 1) % length == read:
                    break                                   # (the ring is full)
                address = dst - len(prefix) + i + 3         # the code byte's physical address
                self.sim.mu.mem_write(0x80000000 + ring + 4 * write, address.to_bytes(4, 'little'))
                write = (write + 1) % length
                self.codes += 1
            i = buf.find(b"\x00\x00\x01", i + 3)
        self.sim.mu.mem_write(0xB8000000 + self.BASE + self.SC_WRITE + 2 * ch, write.to_bytes(2, 'little'))

    def _read_done(self, uc, access, address, size, value, user_data):
        ch = (address & 0xFFFFFF) - self.BASE - self.DONE
        uc.mem_write(address, bytes(self.done[ch:ch + size]))


class MirrorRegisters:
    """Status registers that follow another register at once: the hardware
    has consumed everything the firmware queued.  The sound engine at
    0xB8002000 streams PCM from a ring in RAM (base +0x30, size +0x34): the
    firmware fills it (silence at boot, through the DMA rings), writes the
    write index to +0x38 and waits until the read index at +0x3A catches up.
    {register offset: (register it mirrors, size in bytes)}."""
    def __init__(self, sim, mirrors):
        self.mirrors = mirrors
        for offset, (_source, size) in mirrors.items():
            sim._mmio_on('r', self._read, offset, offset + size - 1)

    def _read(self, uc, access, address, size, value, user_data):
        offset = address & 0xFFFFFF
        for target, (source, n) in self.mirrors.items():
            if target <= offset < target + n:
                uc.mem_write(0xB8000000 + target, bytes(uc.mem_read(0xB8000000 + source, n)))


class Otp:
    """The one-time-programmable memory's controller at 0xB8042000 (1 KB of
    bits that can only be set), as the M3821 / C3505 firmwares' OTP driver uses
    it (T750i 0x803EFCB0..0x803EFF54): +04 the byte address, +08 a byte to
    burn, +0C the command -- bit 8 reads the 32-bit word at the address into
    +18, bit 0 burns +08 into the byte at it --, +10 the busy bits (8: read,
    0: burn) the driver polls, +14 a burn's result (bit 0 clear: done).
    Commands complete at once.  A board's sidecar may give contents
    (device.otp, dump_catalog.otp); none does: the Fergusons' firmwares look
    at two 64-byte halves of a signature at 0x1C0 and 0x3A0 -- blank, every
    minute of play their UI shows "STB not signed!", as an unsigned box's
    would -- and a non-blank stand-in there sends their start-up down the
    signed path (its RSA check), where the simulator crashed."""
    BASE = 0x42000
    SIZE = 0x400
    ADDRESS, DATA, COMMAND, DATA_OUT = 0x04, 0x08, 0x0C, 0x18

    def __init__(self, sim, contents=None):
        self.sim = sim
        self.data = bytearray(self.SIZE)
        for offset, blob in (contents or {}).items():
            self.data[offset:offset + len(blob)] = blob[:self.SIZE - offset]
        self.reads = self.burns = 0
        sim._mmio_on('w', self._write_command, self.BASE + self.COMMAND, self.BASE + self.COMMAND + 3)

    def _reg(self, offset, size=4):
        return int.from_bytes(self.sim.mu.mem_read(0xB8000000 + self.BASE + offset, size), 'little')

    def _write_command(self, uc, access, address, size, value, user_data):
        """Run a read or burn command; its start bits read back clear."""
        self.sim._device_access(uc)
        value <<= 8 * ((address & 0xFFFFFF) - self.BASE - self.COMMAND)
        at = self._reg(self.ADDRESS) & (self.SIZE - 1)
        if value & 0x100:
            word = at & ~3
            uc.mem_write(0xB8000000 + self.BASE + self.DATA_OUT, bytes(self.data[word:word + 4]))
            self.reads += 1
        if value & 0x001:
            self.data[at] |= self._reg(self.DATA, 1)
            uc.mem_write(0xB8000000 + self.BASE + 0x14, bytes(4))
            self.burns += 1
        cleared = value & ~0x101
        return (cleared >> (8 * ((address & 0xFFFFFF) - self.BASE - self.COMMAND))) & ((1 << (8 * size)) - 1)


class Demodulator(DemodulatorLock):
    """The chip's own DVB-T / T2 demodulator ("NIM_S3821_0"), registers memory-
    mapped at 0xB804C000 + register (the nim_device's base address).  Its
    get_lock() (R265 Lite 1.1.5, 0x804B3558) reads the standard from the upper
    nibble of register 0x2FF (written by the driver, so RAM keeps it) and then,
    for DVB-T (1, 2), tests bit 6 of register 0x1D (0x804B34CC); for DVB-T2
    (4) it wants the low nibble of register 0x67 at 0xA or above and, from the
    two bytes at 0x11D, the second below the first minus one (0x804B33DC).
    With `signal` on those registers read that way (on the tuned frequency,
    when the signal is only on some: sim.tuned_to_signal)."""
    BASE = 0x4C000
    LOCKED = {0x01D: lambda v: v | 0x40,            # DVB-T locked
              0x067: lambda v: (v & 0xF0) | 0x0F,    # DVB-T2 state machine: locked
              0x11D: lambda v: 0x20,
              0x11E: lambda v: 0x00}


class M3821(ChipFamily):
    name = "M3821"
    chip_id = 0x3821
    chip_variant = 0x0010       # the M3822P: the application's chip-ID function wants
                                # (word & 0xFFFF00F0) == 0x38210010, else it reboots

    @classmethod
    def matches(cls, image):
        if bytes(image[0x20:0x25]) == b"M3821":         # the bootloader chunk's version string
            return True
        chunks = chunk_chain(image)
        if any(name.lower() == "hdcpkey" and ver.startswith("M3821") for _o, name, ver in chunks):
            return True
        if not xip_bootloader(image) or not any(name.lower() == "seecode" for _o, name, _v in chunks):
            return False
        from .m3503 import M3503
        from .m3602 import M3602
        if M3503.matches(image) or M3602.matches(image):
            return False
        return b"NIM_S3821" in maincode(image)

    def variant(self):
        # XIP M3821 builds (T750i, Amiko T58) want plain M3821 revision B (low byte
        # != 0 -> revision 0x20002; 0 leaves GMA to SEE); boot-ROM M3822P builds
        # (R265 Lite) want 0x0010.
        return 0x0001 if xip_bootloader(self.sim.rom_image) else self.chip_variant

    def _configure_boot_mode(self):
        sim = self.sim
        self.xip = xip_bootloader(sim.rom_image)
        if self.car is not None:
            self.car.remove()
            self.car = None
        if self.xip:
            self.car = CacheAsRam(sim)

    def install(self):
        sim = self.sim
        self.xip = False
        self.car = None
        super().install()
        # (count_hz stays at the simulator's 100 MHz although the chip's Count runs at
        # 297 MHz: at the real rate the kernel's 1 ms tick is shorter than the host time
        # its hooked CP0 instructions take, and the next tick lands inside its task
        # switch -- between its Count reset and Compare write -- which wedges it.  The
        # application's time therefore runs at a third of real time.)
        # The boot SRAM, in place of the flash mirror the M3801 shows there
        self.sram = ctypes.create_string_buffer(SRAM_SIZE)
        self._sram_mapped = False
        self._set_sram_mapped(True)
        self.ddr = DdrTraining(sim)
        self.spi = SpiStream(sim)
        self.dma = DmaRings(sim)
        self.demod = Demodulator(sim)
        # the transport-stream demultiplexer DMX0 at 0xB8022000, the M3801's block (dmx_m36.py),
        # whose PID filters this generation's driver writes as single entries; it polls the ring
        from dmx_m36 import Demux
        self.dmx = Demux(sim, pid_entries=True)
        # the OTP memory, with what the board's sidecar says its chip holds
        import dump_catalog
        self.otp = Otp(sim, dump_catalog.otp(sim.dump_path) if getattr(sim, "dump_path", None) else None)
        self.ready = ReadyBits(sim, {
            0x000633: 0x80,     # the PLL at 0xB8000600..: locked (polled after it is programmed)
        })
        self.mirrors = MirrorRegisters(sim, {
            0x00203A: (0x002038, 2),    # the sound engine's read index has caught up with the write index
        })
        # Start bits the application sets and then waits to see cleared (the simulator's
        # _SELF_COMPLETING mechanism): bit 4 of +0x6F of the block at 0xB802A000 (most likely
        # the HDMI transmitter: both firmwares set it up at start and poll +0x08 bit 0 like a
        # hot-plug line), whose +0x6F firmware 1.2.0 spins on before it draws anything --
        # probably a DDC transfer of the TV's EDID (288 more operations at +0x70 / +0x72).
        sim._SELF_COMPLETING = {**sim._SELF_COMPLETING, 0x2A06F: (0x10, 0x00, 0x10)}
        sim._mmio_on('r', sim._hook_selfcomplete_read, 0x2A06C, 0x2A06F)
        self.see = SeeStart(sim)
        self._configure_boot_mode()

    def _set_sram_mapped(self, mapped):
        """Show the boot SRAM at 0x1FE00000 / 0x9FE00000 / 0xBFE00000 (True, at
        reset) or the flash mirror there (False, once a 256 MB board moves
        SYS_FLASH_BASE_ADDR to 0xBFC00000 so 0xBFE00000..0xBFEFFFFF is flash
        offset 0x200000..0x2FFFFF)."""
        if mapped == self._sram_mapped:
            return
        sim = self.sim
        ptr = ctypes.addressof(self.sram)
        for seg in (0x00000000, 0x80000000, 0xA0000000):
            sim.mu.mem_unmap(seg + SRAM_PHYS, SRAM_SIZE)
            if mapped:
                sim.mu.mem_map_ptr(seg + SRAM_PHYS, SRAM_SIZE, UC_PROT_ALL, ptr)
            else:
                sim._map_flash_mirror(seg + SRAM_PHYS, SRAM_SIZE)
        self._sram_mapped = mapped

    def uninstall(self):
        """The flash mirror back where the boot SRAM and the cache-as-RAM range
        were, the flash window's normal read mode, the common self-completing
        registers."""
        sim = self.sim
        if self.car is not None:
            self.car.remove()
            self.car = None
        self._set_sram_mapped(False)
        sim._spi_stream = None
        del sim._SELF_COMPLETING            # (the instance's copy with 0x2A06F: the class's again)
        super().uninstall()

    def start(self):
        """What the boot ROM does: the bootloader area into the SRAM, enter it
        (an XIP bootloader starts at the flash window, like the M3801's)."""
        sim = self.sim
        self._configure_boot_mode()
        if self.xip:
            sim.mu.reg_write(UC_MIPS_REG_PC, sim.base_addr)
            return
        self._set_sram_mapped(True)
        ctypes.memmove(ctypes.addressof(self.sram), bytes(sim.rom_image[:BOOT_COPY]), BOOT_COPY)
        sim._rescan_cp0_sites(self.code_ranges())
        sim.mu.reg_write(UC_MIPS_REG_PC, ENTRY)

    def code_ranges(self):
        return [] if self.xip else [(0x80000000 + SRAM_PHYS, BOOT_COPY), (0x82800000, 0x100000)]
