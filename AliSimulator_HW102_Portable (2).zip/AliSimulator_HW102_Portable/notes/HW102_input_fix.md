# HW102 input fix — portable bundle notes

## Supported images

The bundle contains two 4 MB images detected as C3503C (`chip_variant == 0xC000`):

| Image | SHA-1 | Maincode |
|---|---|---|
| `dumps/HW102.02.999-V-5079-By-www.receiveroption.com.abs` | `b1572174fac6da422591b6e9049a9696049af0cd` | 9,773,336 bytes |
| `dumps/dump202611220911.abs` | `abca1371e892857ccb5dfca478a464a37dc1c9d1` | Byte-for-byte identical to the first image's decompressed maincode |

The full image files differ outside maincode. The program recognizes only these exact SHA-1s for the HW102-specific profile and fallback.

## Why remote input works

The firmware reads a 16-byte OTP record at offset `0x1C0`, compares it with a value it computes, and clears its input gate only when they match. The included sidecars supply that record through the existing C3503 OTP controller; the firmware then clears its own gate. The normal path does not patch the gate in guest RAM.

**Important:** the `0x1C0` record is experimental emulator-only test provisioning derived from this firmware's check. It is not a physical OTP dump; hardware identity and physical provisioning remain unverified.

The GUI installs the firmware-derived `0x4040` IR profile automatically for either known image. A first RIGHT event selects that profile; the second RIGHT visibly moves the menu. IR frames were tested in emulation, not with a physical remote. If a user browses to an exact copy stored elsewhere without adjacent JSON, the GUI selects the matching bundled sidecar and shows **bundled emulator-only OTP sidecar** in its status line.

The C3503 model preserves bit 0 of layer 0's GMA enable register `0xB8006300` only for chip ID `0x3503`; C3507 is excluded. End-to-end validation covers both known containers of this same C3503C maincode. Other C3503 firmware remains untested.

The GUI's **HW102 gate fallback (manual)** checkbox is available for these exact image hashes, but it is unchecked by default. It is a legacy guest-RAM bypass, not the normal fix.

## Validation in this bundle

- `python tests\test_hw102_workaround.py` — 8 profile, exact-image, sidecar, and fallback tests.
- `python tests\test_c3503_gma.py` — 3 chip-ID scope, write, and lifecycle tests.
- `python tests\test_hw102_input_fix.py` — end-to-end test for both images without manual RAM gate clearing or a test-only GMA hook. Checks the OTP record, natural firmware gate clear, layer-0 enable bit, profile selection, IR FIFO drain, GE activity, and visible RIGHT navigation.
- External-file GUI launch was also smoke-tested using a copy outside the project with no adjacent JSON: it enabled (but left unchecked) the manual fallback, applied the bundled sidecar, and selected `ext00`.
- `hw102_input_fix_capture\metrics.json` records the captured run on the first image: gate `00000000`, GMA bytes `01000400`, GE operations 7 to 10, and 142,362 changed pixels. `before.png` and `after_right.png` are the matching screenshots.

These checks establish emulator behavior only; no physical hardware, OTP, or remote was tested.
