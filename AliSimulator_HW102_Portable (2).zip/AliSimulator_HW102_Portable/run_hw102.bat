@echo off
setlocal
cd /d "%~dp0"
title AliSimulator - HW102

set "DUMP=dumps\dump202611220911.abs"
if not exist "%DUMP%" (
    echo ERROR: The included HW102 firmware image is missing:
    echo   %DUMP%
    goto :fail
)

if not exist ".venv\Scripts\python.exe" (
    echo Creating a local Python environment...
    where py >nul 2>nul
    if not errorlevel 1 (
        py -3 -m venv .venv
    ) else (
        where python >nul 2>nul
        if errorlevel 1 goto :no_python
        python -m venv .venv
    )
    if errorlevel 1 goto :fail
)

set "PYTHON=%CD%\.venv\Scripts\python.exe"
"%PYTHON%" -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)" >nul 2>nul
if errorlevel 1 (
    echo ERROR: Python 3.10 or newer is required. Install Python from python.org and run this again.
    goto :fail
)

"%PYTHON%" -c "import tkinter, unicorn, capstone, numpy, PIL" >nul 2>nul
if errorlevel 1 (
    echo Installing AliSimulator's Python packages. Internet access is needed the first time...
    "%PYTHON%" -m pip install -r requirements.txt
    if errorlevel 1 goto :fail
)

"%PYTHON%" -c "import tkinter, unicorn, capstone, numpy, PIL" >nul 2>nul
if errorlevel 1 (
    echo ERROR: Python packages or Tkinter are still unavailable.
    echo Install Python 3.10+ with Tcl/Tk support, then run this again.
    goto :fail
)

rem Use the tested default engine even if the PC has another engine setting.
set "ALISIM_ENGINE=unicorn"
"%PYTHON%" "src\tv_gui.py" "%DUMP%"
if errorlevel 1 goto :fail
exit /b 0

:no_python
echo ERROR: Python 3.10 or newer was not found.
echo Install Python from https://www.python.org/downloads/windows/ and enable Tcl/Tk.
:fail
echo.
echo AliSimulator could not start. Review the message above, then try again.
pause
exit /b 1
